# Migration MySQL → PostgreSQL - Guide

## Changements apportés

### 1. Driver de base de données
- **Ancien**: `mysql2` (MySQL)
- **Nouveau**: `pg` (PostgreSQL)
- **Fichier**: `backend/db.js`

### 2. API de requête
- **Ancien**: `const [rows] = await pool.query(...)`
- **Nouveau**: `const result = await pool.query(...); const rows = result.rows;`

### 3. Placeholders de paramètres
- **Ancien**: `WHERE email = ?` et `VALUES (?, ?, ?)`
- **Nouveau**: `WHERE email = $1` et `VALUES ($1, $2, $3)`

### 4. Gestion des transactions
- **Ancien**: `const connection = await pool.getConnection(); await connection.beginTransaction();`
- **Nouveau**: `const client = await pool.connect(); await client.query('BEGIN');`

### 5. Syntaxe INSERT/UPDATE
- **Ancien**: `INSERT INTO users SET ?` et `UPDATE users SET ? WHERE id = ?`
- **Nouveau**: 
  ```sql
  INSERT INTO users (id, email, password, role) VALUES ($1, $2, $3, $4)
  UPDATE users SET email = $1, password = $2 WHERE id = $3
  ```

### 6. Types de données
- **Ancien**: `DATETIME` → **Nouveau**: `TIMESTAMP`
- **Ancien**: `LONGTEXT` → **Nouveau**: `TEXT`
- **Ancien**: `JSON_OBJECT()` → **Nouveau**: `jsonb_build_object()`

### 7. Noms de colonnes
- PostgreSQL traite les noms de colonnes case-sensitively et en minuscules si non quotés
- Pour les colonnes avec camelCase: utiliser des guillemets, ex: `"caissesReservees"`

### 8. Gestion des connexions
- **Ancien**: `connection.release()`
- **Nouveau**: `client.release()`

## Files modifiés
- ✅ `backend/package.json` - Remplacé mysql2 par pg
- ✅ `backend/db.js` - Nouvelle configuration PostgreSQL
- ✅ `backend/server.js` - Migrations SQL adaptées
- ✅ `backend/.env` - Configuration PostgreSQL locale
- ✅ `backend/routes/auth.js` - Syntaxe PostgreSQL appliquée
- ✅ `backend/routes/clients.js` - Syntaxe PostgreSQL appliquée
- ✅ `backend/routes/products.js` - Syntaxe PostgreSQL appliquée
- ✅ `backend/routes/rooms.js` - Syntaxe PostgreSQL appliquée
- ✅ `backend/routes/settings.js` - Syntaxe PostgreSQL appliquée
- ⏳ `backend/routes/movements.js` - À adapter
- ⏳ `backend/routes/locations.js` - À adapter
- ⏳ `backend/routes/invoices.js` - À adapter
- ⏳ `backend/routes/contracts.js` - À adapter

## Prochaines étapes
1. Installer PostgreSQL localement
2. Créer la base de données `frigo_db`
3. Exécuter: `npm install` dans `backend/`
4. Adapter les routes restantes
5. Tester les endpoints API
