# Guide de Génération de l'APK Android

Ce document vous explique comment transformer votre projet **Frigo** en un fichier APK installable sur votre téléphone Android.

## Prérequis

Pour générer l'APK, vous devez avoir installé les outils suivants sur votre ordinateur :

1.  **Node.js & NPM** (déjà présents dans le projet).
2.  **Android Studio** : [Télécharger ici](https://developer.android.com/studio).
3.  **Android SDK** : Installé automatiquement avec Android Studio.

---

## Étapes de Génération

### 1. Préparer les fichiers de l'application
Ouvrez un terminal dans le dossier du projet et exécutez la commande suivante :
```bash
npm run mobile:build
```
Cette commande va :
- Créer une version optimisée du site web (dossier `dist`).
- Copier ces fichiers dans le projet Android (`npx cap sync android`).

### 2. Ouvrir le projet dans Android Studio
Exécutez cette commande :
```bash
npm run mobile:open
```
Ou bien ouvrez Android Studio manuellement et choisissez d'ouvrir le dossier `android` situé dans votre dossier projet.

### 3. Générer l'APK
Une fois le projet chargé dans Android Studio :

1.  Allez dans le menu en haut : **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
2.  Attendez que Gradle termine la compilation (cela peut prendre quelques minutes).
3.  Une notification apparaîtra en bas à droite une fois terminé. Cliquez sur **locate** pour trouver votre fichier `app-debug.apk`.

---

## Installation sur le téléphone

1.  Copiez le fichier `.apk` sur votre téléphone Android.
2.  Ouvrez le fichier sur votre téléphone pour lancer l'installation.
    - *Note : Vous devrez probablement autoriser l'installation d'applications provenant de sources inconnues dans les paramètres de votre téléphone.*

---

## Dépannage (Troubleshooting)

- **Erreur de version Gradle** : Si Android Studio vous demande de mettre à jour Gradle, acceptez la mise à jour recommandée.
- **Erreur de SDK** : Assurez-vous d'avoir installé les "Build Tools" dans le SDK Manager d'Android Studio (généralement Android 13 ou 14).
- **Modification du code** : Si vous modifiez le code de l'application (fichiers `.tsx`, CSS, etc.), n'oubliez pas de relancer `npm run mobile:build` avant de reconstruire l'APK dans Android Studio.

---

*Ce document a été généré pour vous aider à finaliser la conversion mobile de votre projet.*
