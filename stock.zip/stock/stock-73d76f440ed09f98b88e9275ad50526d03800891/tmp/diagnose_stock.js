
const mysql = require('mysql2/promise');
require('dotenv').config();

async function diagnose() {
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'frigo_db'
    });

    try {
        console.log('--- DIAGNOSTIC DES STOCKS ---');
        
        const [clients] = await connection.query('SELECT id, nom, prenom FROM clients');
        
        for (const client of clients) {
            console.log(`\nClient: ${client.nom} ${client.prenom} (${client.id})`);
            
            // 1. Calculer le stock théorique à partir des mouvements
            const [entries] = await connection.query(
                `SELECT productId, roomId, SUM(nbCaisse) as total 
                 FROM movements 
                 WHERE clientId = ? AND type = 'Location' 
                 GROUP BY productId, roomId`, 
                [client.id]
            );
            
            const [withdrawals] = await connection.query(
                `SELECT productId, roomId, SUM(COALESCE(nbCaisse, nbCaisseRetournees, 0)) as total 
                 FROM movements 
                 WHERE clientId = ? AND (type = 'Vente' OR type = 'Fin de Location') 
                 GROUP BY productId, roomId`, 
                [client.id]
            );

            // 2. Récupérer le stock actuel en base (table locations)
            const [current] = await connection.query(
                `SELECT productId, roomId, SUM(nbCaisse) as total 
                 FROM locations 
                 WHERE clientId = ? AND status = 'En cours' 
                 GROUP BY productId, roomId`, 
                [client.id]
            );

            // Comparaison simple
            console.log('Lot (Produit | Chambre) | Mouvements (Entrées - Sorties) | Table Locations | Status');
            
            const allKeys = new Set([
                ...entries.map(e => `${e.productId}|${e.roomId}`),
                ...current.map(c => `${c.productId}|${c.roomId}`)
            ]);

            for (const key of allKeys) {
                const [pId, rId] = key.split('|');
                const ent = entries.find(e => e.productId === pId && e.roomId === rId)?.total || 0;
                const wit = withdrawals.find(w => w.productId === pId && w.roomId === rId)?.total || 0;
                const cur = current.find(c => c.productId === pId && c.roomId === rId)?.total || 0;
                
                const theoretical = ent - wit;
                const diff = cur - theoretical;
                
                const status = diff === 0 ? '✅ OK' : `❌ ERREUR (Diff: ${diff})`;
                console.log(`${pId.substring(0,8)} | ${rId.substring(0,8)} | ${theoretical} caisses | ${cur} caisses | ${status}`);
            }
        }

    } catch (error) {
        console.error('Erreur diagnostic:', error);
    } finally {
        await connection.end();
    }
}

diagnose();
