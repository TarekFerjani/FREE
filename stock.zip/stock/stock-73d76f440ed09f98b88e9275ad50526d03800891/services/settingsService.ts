import { Settings } from '../types';
import { apiService } from './apiService';

export const settingsService = {
  getSettings: (): Promise<Settings> => {
    return apiService.get<Settings>('/settings');
  },

  saveSettings: (settings: Settings): Promise<Settings> => {
    return apiService.put<Settings>('/settings', settings);
  },
  
  resetAllData: (): Promise<void> => {
    // C'est une opération dangereuse, elle appelle donc un endpoint backend spécifique.
    return apiService.post<void>('/settings/reset-data', {});
  },

  testDbConnection: (): Promise<{ ok: boolean; message: string }> => {
    return apiService.post<{ ok: boolean; message: string }>('/settings/test-db-connection', {});
  }
};