# Guide de Déploiement sur VPS (Docker) 🐋

Ce guide explique comment déployer votre application sur votre VPS en utilisant Docker.

## 1. Préparation du VPS

Assurez-vous que **Docker** et **Docker Compose** sont installés sur votre VPS.

```bash
# Vérifier l'installation
docker --version
docker-compose --version
```

## 2. Transfert des fichiers

Transférez le dossier de votre projet sur le VPS (via FTP, SCP ou Git).

## 3. Configuration des variables d'environnement

Sur le VPS, créez ou modifiez le fichier `backend/.env` :

```bash
# Données de la base de données (gardez vos accès actuels ou utilisez localhost si la DB est sur le VPS)
DB_HOST=85.215.215.242 
DB_PORT=3306
DB_USER=root
DB_PASSWORD=root
DB_DATABASE=frigo_db

# Configuration Email
EMAIL_USER=votre-email@gmail.com
EMAIL_PASS=votre-mot-de-passe-application

# IMPORTANT : URL du frontend pour les liens de signature
FRONTEND_URL=http://<IP_DE_VOTRE_VPS>:3000
```

## 4. Lancement de l'application

Placez-vous à la racine du projet sur le VPS et lancez la commande suivante :

```bash
# Construire et lancer les conteneurs en arrière-plan
docker-compose up -d --build
```

## 5. Accès à l'application

L'application sera accessible aux adresses suivantes :
- **Frontend** : `http://<IP_DE_VOTRE_VPS>:3000`
- **Backend API** : `http://<IP_DE_VOTRE_VPS>:3001/api` (géré automatiquement par le proxy)

## Commandes Utiles

- **Voir les logs** : `docker-compose logs -f`
- **Arrêter l'app** : `docker-compose down`
- **Redémarrer après une modification** : `docker-compose up -d --build`

---
*Note : Pour une mise en production avec un nom de domaine (HTTPS), il est recommandé d'ajouter un certificat SSL via Certbot ou d'utiliser un reverse proxy comme Traefik ou Nginx Proxy Manager.*
