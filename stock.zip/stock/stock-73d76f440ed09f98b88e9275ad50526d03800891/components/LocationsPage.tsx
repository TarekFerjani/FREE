import React, { useMemo } from 'react';
import { Location, Client, Product, Room } from '../types';

interface LocationsPageProps {
  locations: Location[];
  clients: Client[];
  products: Product[];
  rooms: Room[];
  isLoading: boolean;
  searchTerm: string;
}

type EnrichedLocation = Location & {
    clientName: string;
    productName: string;
    roomName: string;
}

const LocationsPage: React.FC<LocationsPageProps> = ({ locations, clients, products, rooms, isLoading, searchTerm }) => {
  const enrichedLocations: EnrichedLocation[] = useMemo(() => {
    const clientMap = new Map(clients.map(c => [c.id, `${c.nom} ${c.prenom}`]));
    const productMap = new Map(products.map(p => [p.id, p.nom]));
    const roomMap = new Map(rooms.map(r => [r.id, r.nom]));
    
    return locations.map(loc => ({
        ...loc,
        clientName: clientMap.get(loc.clientId) || 'N/A',
        productName: productMap.get(loc.productId) || 'N/A',
        roomName: roomMap.get(loc.roomId) || 'N/A'
    }));
  }, [locations, clients, products, rooms]);

  const filteredLocations = useMemo(() => {
    return enrichedLocations.filter(loc =>
      loc.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loc.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loc.roomName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loc.status.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [enrichedLocations, searchTerm]);


  const renderContent = () => {
    if (isLoading) {
      return <div className="text-center py-10">Chargement des locations...</div>;
    }
    if (filteredLocations.length === 0) {
      return <div className="text-center py-10 bg-white rounded-lg shadow-md">Aucune location trouvée.</div>;
    }
    return (
        <>
            <div className="hidden md:block bg-white shadow-md rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produit</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Chambre</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Caisses (Actuel/Initial)</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date d'entrée</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredLocations.map(loc => (
                                <tr key={loc.id}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${loc.status === 'En cours' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                            {loc.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{loc.clientName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{loc.productName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{loc.roomName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{loc.nbCaisse} / {loc.initialNbCaisse}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(loc.entryDate).toLocaleDateString('fr-FR')}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <div className="md:hidden space-y-4">
                {filteredLocations.map(loc => (
                    <div key={loc.id} className="bg-white p-4 rounded-lg shadow-md">
                        <div className="flex justify-between items-start">
                             <h3 className="text-md font-bold text-gray-900">{loc.productName}</h3>
                             <span className={`px-2 py-1 text-xs font-semibold rounded-full ${loc.status === 'En cours' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{loc.status}</span>
                        </div>
                        <div className="mt-2 space-y-1 text-sm text-gray-600">
                            <p><span className="font-medium">Client:</span> {loc.clientName}</p>
                            <p><span className="font-medium">Chambre:</span> {loc.roomName}</p>
                            <p><span className="font-medium">Caisses:</span> {loc.nbCaisse} sur {loc.initialNbCaisse}</p>
                            <p><span className="font-medium">Entrée:</span> {new Date(loc.entryDate).toLocaleDateString('fr-FR')}</p>
                        </div>
                    </div>
                ))}
            </div>
        </>
    );
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold text-gray-700">État des Locations</h1>
      </div>
      {renderContent()}
    </div>
  );
};

export default LocationsPage;