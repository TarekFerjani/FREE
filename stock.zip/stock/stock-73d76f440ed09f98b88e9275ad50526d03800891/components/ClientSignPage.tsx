import React, { useState, useEffect } from 'react';
import SignaturePad from './SignaturePad';

interface ContractData {
  id: string;
  date: string;
  clientId: string;
  type: string;
  nbCaisse: number;
  caution: number;
  avance: number;
  periode: string;
  status: string;
  signature?: string;
  signedAt?: string;
  companyName?: string;
  currencySymbol?: string;
  husbandName?: string;
  husbandCin?: string;
  husbandDob?: string;
  wifeName?: string;
  wifeCin?: string;
  wifeDob?: string;
  witness1Name?: string;
  witness1Cin?: string;
  witness2Name?: string;
  witness2Cin?: string;
  dowry?: number;
  regimeOption?: string;
  husbandSignature?: string;
  wifeSignature?: string;
  husbandSignedAt?: string;
  wifeSignedAt?: string;
}

const ClientSignPage: React.FC<{ contractId: string }> = ({ contractId }) => {
  const [contract, setContract] = useState<ContractData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [signatureData, setSignatureData] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [signed, setSigned] = useState(false);
  const [signRole, setSignRole] = useState<'husband' | 'wife' | null>(null);
  const [waitingForOther, setWaitingForOther] = useState(false);

  const fetchContract = async () => {
    try {
      const res = await fetch(`/api/contracts/public/${contractId}`);
      if (!res.ok) throw new Error('Contrat introuvable');
      const data = await res.json();
      setContract(data);
      if (data.type === 'Mariage') {
        if (data.husbandSignature && data.wifeSignature) {
          setSigned(true);
          setWaitingForOther(false);
        } else {
          // Pre-select role if only one is unsigned
          if (data.husbandSignature && !data.wifeSignature) {
            setSignRole('wife');
          } else if (!data.husbandSignature && data.wifeSignature) {
            setSignRole('husband');
          }
        }
      } else {
        if (data.signature) setSigned(true);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContract();
  }, [contractId]);

  const handleSign = async () => {
    if (!signatureData || !contract) {
      alert('Veuillez dessiner votre signature avant de valider.');
      return;
    }
    if (contract.type === 'Mariage' && !signRole) {
      alert('Veuillez indiquer si vous signez en tant qu\'époux ou épouse.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`/api/contracts/public/${contractId}/sign`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signature: signatureData, role: signRole })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Erreur lors de la signature');
      }
      const result = await res.json();
      if (contract.type === 'Mariage') {
        if (result.bothSigned || result.status === 'Actif') {
          setSigned(true);
          setWaitingForOther(false);
        } else {
          setWaitingForOther(true);
        }
      } else {
        setSigned(true);
      }
      setSignatureData(null);
      await fetchContract();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement du contrat...</p>
        </div>
      </div>
    );
  }

  if (error || !contract) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="text-red-500 text-5xl mb-4">⚠️</div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Contrat introuvable</h2>
          <p className="text-gray-600">{error || 'Ce lien est invalide ou le contrat a été supprimé.'}</p>
        </div>
      </div>
    );
  }

  if (waitingForOther) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-indigo-50 p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="text-purple-500 text-6xl mb-4">💍</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Signature enregistrée !</h2>
          <p className="text-gray-600 mb-4">Votre consentement a été validé avec succès.</p>
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-sm text-purple-800 text-left space-y-2">
            <p className="font-semibold text-center">⏳ En attente de la deuxième signature</p>
            <p>L'acte de mariage requiert la signature de l'époux <strong>et</strong> de l'épouse pour être finalisé.</p>
            <p className="text-xs text-purple-700 font-mono mt-1">Référence : #{contract.id.substring(0, 8).toUpperCase()}</p>
          </div>
          <p className="text-xs text-gray-400 mt-6">Dès que le deuxième conjoint aura signé, les e-mails de confirmation bilingues avec le PDF signé seront envoyés automatiquement.</p>
        </div>
      </div>
    );
  }

  if (signed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-50 p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="text-green-500 text-6xl mb-4">✅</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Contrat signé !</h2>
          <p className="text-gray-600 mb-4">Les signatures électroniques ont été enregistrées avec succès.</p>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-sm text-green-800">
            <p className="font-semibold">📋 Référence : #{contract.id.substring(0, 8).toUpperCase()}</p>
            <p>🕐 Horodatage final : {contract.signedAt ? new Date(contract.signedAt).toLocaleString('fr-TN') : new Date().toLocaleString('fr-TN')}</p>
            {contract.type === 'Mariage' && <p className="mt-1 text-xs">💍 Acte de mariage tunisien bilingue validé.</p>}
          </div>
          <p className="text-xs text-gray-400 mt-6">Vous pouvez fermer cette page. Les exemplaires PDF ont été envoyés par e-mail.</p>
        </div>
      </div>
    );
  }

  const currency = contract.currencySymbol || 'DT';
  const company = contract.companyName || 'L\'entreprise';
  const isMarriage = contract.type === 'Mariage';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className={`bg-gradient-to-r ${isMarriage ? 'from-purple-600 to-indigo-700' : 'from-primary-600 to-indigo-700'} rounded-xl p-5 text-white mb-4 shadow-lg`}>
          <h1 className="text-xl font-bold mb-1">{isMarriage ? '💍 Acte de Mariage Électronique' : '📄 Signature de contrat'}</h1>
          <p className="text-sm opacity-90">{company} — Réf. #{contract.id.substring(0, 8).toUpperCase()}</p>
        </div>

        {/* Contract details */}
        <div className="bg-white rounded-xl shadow-md p-5 mb-4">
          <h2 className="text-lg font-semibold text-gray-800 mb-3 border-b pb-2">Détails du contrat</h2>
          
          {isMarriage ? (
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Type</span>
                <span className="font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full text-xs">Contrat de Mariage</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Date</span>
                <span className="font-medium text-gray-800">{new Date(contract.date).toLocaleDateString('fr-TN')}</span>
              </div>
              
              <div className="border-t my-2 pt-2">
                <p className="font-semibold text-gray-700 mb-1 flex items-center justify-between">
                  <span>♂ Époux</span>
                  <span className={contract.husbandSignature ? 'text-green-600 text-xs' : 'text-gray-400 text-xs font-normal'}>
                    {contract.husbandSignature ? 'Signé ✅' : 'En attente ⏳'}
                  </span>
                </p>
                <div className="pl-3 text-xs text-gray-600 space-y-1">
                  <p>Nom: <span className="font-medium text-gray-800">{contract.husbandName || '-'}</span></p>
                  <p>CIN: <span className="font-medium text-gray-800">{contract.husbandCin || '-'}</span></p>
                  <p>Né le: <span className="font-medium text-gray-800">{contract.husbandDob || '-'}</span></p>
                </div>
              </div>

              <div className="border-t my-2 pt-2">
                <p className="font-semibold text-gray-700 mb-1 flex items-center justify-between">
                  <span>♀ Épouse</span>
                  <span className={contract.wifeSignature ? 'text-green-600 text-xs' : 'text-gray-400 text-xs font-normal'}>
                    {contract.wifeSignature ? 'Signé ✅' : 'En attente ⏳'}
                  </span>
                </p>
                <div className="pl-3 text-xs text-gray-600 space-y-1">
                  <p>Nom: <span className="font-medium text-gray-800">{contract.wifeName || '-'}</span></p>
                  <p>CIN: <span className="font-medium text-gray-800">{contract.wifeCin || '-'}</span></p>
                  <p>Née le: <span className="font-medium text-gray-800">{contract.wifeDob || '-'}</span></p>
                </div>
              </div>

              <div className="border-t my-2 pt-2">
                <p className="font-semibold text-gray-700 mb-1">⚖️ Témoins requis</p>
                <div className="pl-3 text-xs text-gray-600 space-y-1">
                  <p>Témoin 1: <span className="font-medium text-gray-800">{contract.witness1Name || '-'}</span> (CIN: {contract.witness1Cin || '-'})</p>
                  <p>Témoin 2: <span className="font-medium text-gray-800">{contract.witness2Name || '-'}</span> (CIN: {contract.witness2Cin || '-'})</p>
                </div>
              </div>

              <hr />
              <div className="flex justify-between">
                <span className="text-gray-500">Régime matrimonial</span>
                <span className="font-bold text-gray-900">{contract.regimeOption || 'Séparation de biens'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Dot (Mahr)</span>
                <span className="font-bold text-gray-900">{Math.round(contract.dowry || 0).toLocaleString('fr-FR')} {currency}</span>
              </div>
            </div>
          ) : (
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Type</span>
                <span className="font-medium text-gray-800">{contract.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Date</span>
                <span className="font-medium text-gray-800">{new Date(contract.date).toLocaleDateString('fr-TN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Nombre de caisses</span>
                <span className="font-medium text-gray-800">{contract.nbCaisse}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Période</span>
                <span className="font-medium text-gray-800">{contract.periode}</span>
              </div>
              <hr />
              <div className="flex justify-between">
                <span className="text-gray-500">Caution</span>
                <span className="font-bold text-gray-900">{contract.caution} {currency}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Avance</span>
                <span className="font-bold text-gray-900">{contract.avance} {currency}</span>
              </div>
            </div>
          )}
        </div>

        {/* Marriage signature role selector */}
        {isMarriage && !contract.husbandSignature && !contract.wifeSignature && (
          <div className="bg-white rounded-xl shadow-md p-5 mb-4">
            <h2 className="text-base font-semibold text-gray-800 mb-3">Qui signe actuellement ?</h2>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setSignRole('husband')}
                className={`py-3 px-2 rounded-lg border-2 font-semibold text-sm transition-all text-center ${
                  signRole === 'husband'
                    ? 'border-purple-600 bg-purple-50 text-purple-800'
                    : 'border-gray-200 hover:border-gray-300 text-gray-600'
                }`}
              >
                ♂ L'Époux<br />
                <span className="text-xs font-normal opacity-85">{contract.husbandName}</span>
              </button>
              <button
                onClick={() => setSignRole('wife')}
                className={`py-3 px-2 rounded-lg border-2 font-semibold text-sm transition-all text-center ${
                  signRole === 'wife'
                    ? 'border-purple-600 bg-purple-50 text-purple-800'
                    : 'border-gray-200 hover:border-gray-300 text-gray-600'
                }`}
              >
                ♀ L'Épouse<br />
                <span className="text-xs font-normal opacity-85">{contract.wifeName}</span>
              </button>
            </div>
          </div>
        )}

        {/* Signature pad area */}
        {(!isMarriage || signRole) && (
          <div className="bg-white rounded-xl shadow-md p-5 mb-4">
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              ✍️ Signature de {isMarriage ? (signRole === 'husband' ? "l'Époux" : "l'Épouse") : "votre contrat"}
            </h2>
            <p className="text-xs text-gray-500 mb-3">Dessinez votre signature ci-dessous avec le doigt ou un stylet</p>
            
            <SignaturePad
              onSave={(dataUrl) => setSignatureData(dataUrl)}
              onClear={() => setSignatureData(null)}
              height="200px"
            />

            {signatureData && (
              <div className="mt-2 flex items-center text-xs text-green-600">
                <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Signature capturée
              </div>
            )}
          </div>
        )}

        {/* Legal notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4 text-xs text-amber-800">
          {isMarriage
            ? "⚖️ En signant, vous validez votre consentement à ce mariage conformément au Code du Statut Personnel tunisien (CSP). La signature sera horodatée électroniquement."
            : "⚖️ En signant, vous acceptez les termes du contrat conformément au Code des Obligations et des Contrats tunisien (COC). La signature sera horodatée automatiquement."}
        </div>

        {/* Submit button */}
        <button
          onClick={handleSign}
          disabled={!signatureData || submitting}
          className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg transition-all ${
            signatureData && !submitting
              ? 'bg-green-600 text-white hover:bg-green-700 active:scale-[0.98]'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          {submitting ? (
            <span className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Enregistrement en cours...
            </span>
          ) : (
            '✅ Valider ma signature'
          )}
        </button>

        <p className="text-center text-xs text-gray-400 mt-4">
          Document sécurisé • Conforme au droit tunisien • Horodatage cryptographique
        </p>
      </div>
    </div>
  );
};

export default ClientSignPage;
