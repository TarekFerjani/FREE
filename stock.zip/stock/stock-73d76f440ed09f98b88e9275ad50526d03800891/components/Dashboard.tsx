
import React from 'react';
import PieChart from './PieChart';
import BarChart from './BarChart';
import StatCard from './StatCard';
import { Location, Invoice, MovementType, Settings, Client, Room } from '../types';

interface DashboardProps {
  locations: Location[];
  clients: Client[];
  invoices: Invoice[];
  rooms: Room[];
  settings: Settings;
}

const Dashboard: React.FC<DashboardProps> = ({ locations, clients, invoices, rooms, settings }) => {
  const stockDistributionData = React.useMemo(() => {
    const clientMap = new Map(clients.map(c => [c.id, `${c.nom} ${c.prenom}`]));
    const stockByClient = locations
      .filter(loc => loc.status === 'En cours')
      .reduce((acc, loc) => {
        const currentStock = acc.get(loc.clientId) || 0;
        acc.set(loc.clientId, currentStock + (Number(loc.nbCaisse) || 0));
        return acc;
      }, new Map<string, number>());

    const colors = ['#3b82f6', '#16a34a', '#ef4444', '#f97316', '#8b5cf6', '#eab308'];
    let colorIndex = 0;

    return Array.from(stockByClient.entries()).map(([clientId, count]) => ({
      label: clientMap.get(clientId) || 'Client inconnu',
      value: count,
      color: colors[colorIndex++ % colors.length],
    }));
  }, [locations, clients]);
  
  const paymentsByClientData = React.useMemo(() => {
    const clientMap = new Map<string, number>();

    // Finalized invoices (ONLY Pending)
    invoices
      .filter(inv => inv.paymentStatus === 'En attente')
      .forEach(inv => {
        const amount = Number((inv as any).loyer || (inv as any).montantTotal) || 0;
        clientMap.set(inv.clientId, (clientMap.get(inv.clientId) || 0) + amount);
      });

    // Ongoing rentals (Accumulated rent)
    locations
      .filter(loc => loc.status === 'En cours' && loc.entryDate)
      .forEach(loc => {
        const entryTime = new Date(loc.entryDate).getTime();
        if (!isNaN(entryTime)) {
          const days = Math.max(1, Math.ceil((new Date().getTime() - entryTime) / (1000 * 60 * 60 * 24)));
          const amount = (days || 0) * (Number(loc.nbCaisse) || 0) * (Number(settings.rentPerCratePerDay) || 0);
          clientMap.set(loc.clientId, (clientMap.get(loc.clientId) || 0) + (isNaN(amount) ? 0 : amount));
        }
      });

    const categories = Array.from(clientMap.entries())
      .map(([clientId, total]) => {
        const client = clients.find(c => c.id === clientId);
        return {
          label: client ? `${client.nom} ${client.prenom}` : 'Inconnu',
          value: Math.round(total)
        };
      })
      .filter(item => item.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 8); // Top 8 clients for readability

    return {
      labels: categories.map(c => c.label),
      datasets: [{
        label: `Reste à payer (${settings.currencySymbol})`,
        data: categories.map(c => c.value),
        color: '#f97316'
      }]
    };
  }, [invoices, locations, clients, settings]);
  
  const paymentStatusData = React.useMemo(() => {
    const statusTotals = invoices
      .filter(inv => inv.type === MovementType.LocationOut)
      .reduce((acc, inv) => {
        const status = inv.paymentStatus || 'En attente';
        const amount = Number((inv as any).loyer || (inv as any).montantTotal) || 0;
        acc[status] = (acc[status] || 0) + amount;
        return acc;
      }, {} as Record<'Payé' | 'En attente', number>);

    // Ajout du montant "En cours" (locations non encore terminées)
    const ongoingLoyer = locations
      .filter(loc => loc.status === 'En cours' && loc.entryDate)
      .reduce((sum, loc) => {
        const entryTime = new Date(loc.entryDate).getTime();
        if (isNaN(entryTime)) return sum;
        const days = Math.max(1, Math.ceil((new Date().getTime() - entryTime) / (1000 * 60 * 60 * 24)));
        const amount = (days || 0) * (Number(loc.nbCaisse) || 0) * (Number(settings.rentPerCratePerDay) || 0);
        return sum + (isNaN(amount) ? 0 : amount);
      }, 0);

    statusTotals['En attente'] = (statusTotals['En attente'] || 0) + ongoingLoyer;

    return [
      { label: 'Payé', value: statusTotals['Payé'] || 0, color: '#16a34a' },
      { label: 'En attente (dont en cours)', value: statusTotals['En attente'] || 0, color: '#f97316' },
    ].filter(item => item.value > 0);
  }, [invoices, locations, settings]);

  const stats = React.useMemo(() => {
    const totalCratesInStock = locations.filter(l => l.status === 'En cours').reduce((sum, l) => sum + (Number(l.nbCaisse) || 0), 0);
    const activeClients = new Set(locations.filter(l => l.status === 'En cours').map(l => l.clientId)).size;
    const ongoingLoyer = locations
      .filter(loc => loc.status === 'En cours' && loc.entryDate)
      .reduce((sum, loc) => {
        const entryTime = new Date(loc.entryDate).getTime();
        if (isNaN(entryTime)) return sum;
        const days = Math.max(1, Math.ceil((new Date().getTime() - entryTime) / (1000 * 60 * 60 * 24)));
        const amount = (days || 0) * (Number(loc.nbCaisse) || 0) * (Number(settings.rentPerCratePerDay) || 0);
        return sum + (isNaN(amount) ? 0 : amount);
      }, 0);

    const pendingTotal = (invoices
      .filter(inv => inv.type === MovementType.LocationOut && inv.paymentStatus === 'En attente')
      .reduce((sum, inv) => sum + (Number((inv as any).loyer || (inv as any).montantTotal) || 0), 0)) + ongoingLoyer;

    const totalCapacity = rooms.reduce((sum, r) => sum + r.nbCaisse, 0);
    const occupancyRate = totalCapacity > 0 ? Math.round((totalCratesInStock / totalCapacity) * 100) : 0;

    return {
        totalCratesInStock,
        activeClients,
        pendingTotal,
        occupancyRate
    };
  }, [locations, invoices, rooms, settings]);
  
  return (
    <div className="space-y-8 pb-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Tableau de bord</h2>
        <p className="text-gray-500 text-sm">Aperçu en temps réel de votre activité de stockage.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Caisses en Stock" value={stats.totalCratesInStock.toString()} icon="box" />
          <StatCard title="Clients Actifs" value={stats.activeClients.toString()} icon="users" />
          <StatCard title="Paiements en Attente" value={`${Math.round(stats.pendingTotal).toLocaleString('fr-FR')} ${settings.currencySymbol}`} icon="cash" />
          <StatCard title="Taux d'occupation" value={`${stats.occupancyRate}%`} icon="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-100">
            <PieChart title="Répartition du Stock par Client" data={stockDistributionData} />
        </div>
        <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-100">
            <PieChart title="État des Paiements des Loyers" data={paymentStatusData} currencySymbol={settings.currencySymbol} />
        </div>
      </div>
      
      <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-100">
        <BarChart title={`Paiements en attente par client (Reste à payer) en ${settings.currencySymbol}`} data={paymentsByClientData} />
      </div>
    </div>
  );
};

export default Dashboard;