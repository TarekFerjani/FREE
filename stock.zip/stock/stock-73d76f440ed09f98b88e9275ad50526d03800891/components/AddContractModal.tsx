import React, { useState } from 'react';
import { Client, Contract } from '../types';

interface AddContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (contract: Partial<Contract>) => void;
  clients: Client[];
}

const AddContractModal: React.FC<AddContractModalProps> = ({ isOpen, onClose, onSave, clients }) => {
  const [formData, setFormData] = useState<Partial<Contract>>({
    type: 'Location',
    nbCaisse: 1,
    caution: 0,
    avance: 0,
    regimeOption: 'Séparation de biens',
    dowry: 0,
  });

  const [dateDebut, setDateDebut] = useState('');
  const [dateFin, setDateFin] = useState('');

  if (!isOpen) return null;

  const isMarriage = formData.type === 'Mariage';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientId) {
      alert('Veuillez sélectionner un client.');
      return;
    }

    if (isMarriage) {
      if (!formData.husbandName || !formData.wifeName) {
        alert('Veuillez saisir les noms complets de l\'époux et de l\'épouse.');
        return;
      }
      onSave({ ...formData, periode: new Date().toLocaleDateString('fr-TN') });
    } else {
      if (!dateDebut || !dateFin) {
        alert('Veuillez sélectionner la période (début et fin).');
        return;
      }
      if (new Date(dateDebut) > new Date(dateFin)) {
        alert('La date de fin doit être supérieure ou égale à la date de début.');
        return;
      }
      const formattedStart = new Date(dateDebut).toLocaleDateString('fr-TN');
      const formattedEnd = new Date(dateFin).toLocaleDateString('fr-TN');
      const periodeStr = `Du ${formattedStart} au ${formattedEnd}`;
      onSave({ ...formData, periode: periodeStr });
    }
  };

  const inputClass = "mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-rose-500 focus:border-rose-500 sm:text-sm";
  const labelClass = "block text-sm font-medium text-gray-700";

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75" onClick={onClose}></div>
        </div>

        <div className="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full">
          <form onSubmit={handleSubmit} className="p-6 space-y-5">

            {/* Header */}
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="text-lg font-bold text-gray-900">Nouveau Contrat</h3>
              <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Client + Type */}
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className={labelClass}>Client (responsable du dossier)</label>
                <select
                  required
                  className={inputClass}
                  value={formData.clientId || ''}
                  onChange={(e) => setFormData({ ...formData, clientId: e.target.value })}
                >
                  <option value="">Sélectionner un client</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.nom} {c.prenom}</option>)}
                </select>
              </div>

              <div className="col-span-2">
                <label className={labelClass}>Type de contrat</label>
                <select
                  className={inputClass}
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                >
                  <option value="Location">📦 Location</option>
                  <option value="Prêt de caisses">🤝 Prêt de caisses</option>
                  <option value="Mariage">💍 Mariage (Loi tunisienne)</option>
                </select>
              </div>
            </div>

            {/* ─── MARIAGE FIELDS ─── */}
            {isMarriage && (
              <div className="space-y-4">
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-sm text-rose-800 font-medium">
                  💍 Contrat de Mariage — Code du Statut Personnel tunisien
                </div>

                {/* Époux */}
                <div>
                  <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs">♂</span>
                    Époux
                  </h4>
                  <div className="grid grid-cols-3 gap-3 bg-blue-50 p-3 rounded-lg">
                    <div className="col-span-3 sm:col-span-1">
                      <label className={labelClass}>Nom complet *</label>
                      <input type="text" required className={inputClass} placeholder="Prénom et Nom"
                        value={formData.husbandName || ''}
                        onChange={(e) => setFormData({ ...formData, husbandName: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>CIN</label>
                      <input type="text" className={inputClass} placeholder="CIN"
                        value={formData.husbandCin || ''}
                        onChange={(e) => setFormData({ ...formData, husbandCin: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>Date de naissance</label>
                      <input type="date" className={inputClass}
                        value={formData.husbandDob || ''}
                        onChange={(e) => setFormData({ ...formData, husbandDob: e.target.value })} />
                    </div>
                    <div className="col-span-3">
                      <label className={labelClass}>📧 Email de l'époux (pour signature)</label>
                      <input type="email" className={inputClass} placeholder="email@exemple.com"
                        value={formData.husbandEmail || ''}
                        onChange={(e) => setFormData({ ...formData, husbandEmail: e.target.value })} />
                    </div>
                  </div>
                </div>

                {/* Épouse */}
                <div>
                  <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-pink-100 text-pink-700 flex items-center justify-center text-xs">♀</span>
                    Épouse
                  </h4>
                  <div className="grid grid-cols-3 gap-3 bg-pink-50 p-3 rounded-lg">
                    <div className="col-span-3 sm:col-span-1">
                      <label className={labelClass}>Nom complet *</label>
                      <input type="text" required className={inputClass} placeholder="Prénom et Nom"
                        value={formData.wifeName || ''}
                        onChange={(e) => setFormData({ ...formData, wifeName: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>CIN</label>
                      <input type="text" className={inputClass} placeholder="CIN"
                        value={formData.wifeCin || ''}
                        onChange={(e) => setFormData({ ...formData, wifeCin: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>Date de naissance</label>
                      <input type="date" className={inputClass}
                        value={formData.wifeDob || ''}
                        onChange={(e) => setFormData({ ...formData, wifeDob: e.target.value })} />
                    </div>
                    <div className="col-span-3">
                      <label className={labelClass}>📧 Email de l'épouse (pour signature)</label>
                      <input type="email" className={inputClass} placeholder="email@exemple.com"
                        value={formData.wifeEmail || ''}
                        onChange={(e) => setFormData({ ...formData, wifeEmail: e.target.value })} />
                    </div>
                  </div>
                </div>

                {/* Témoins */}
                <div>
                  <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-xs">👥</span>
                    Témoins (الشهود)
                  </h4>
                  <div className="grid grid-cols-2 gap-3 bg-green-50 p-3 rounded-lg">
                    <div>
                      <label className={labelClass}>Témoin 1 — Nom complet</label>
                      <input type="text" className={inputClass} placeholder="Nom du 1er témoin"
                        value={formData.witness1Name || ''}
                        onChange={(e) => setFormData({ ...formData, witness1Name: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>Témoin 1 — CIN</label>
                      <input type="text" className={inputClass} placeholder="CIN"
                        value={formData.witness1Cin || ''}
                        onChange={(e) => setFormData({ ...formData, witness1Cin: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>Témoin 2 — Nom complet</label>
                      <input type="text" className={inputClass} placeholder="Nom du 2ème témoin"
                        value={formData.witness2Name || ''}
                        onChange={(e) => setFormData({ ...formData, witness2Name: e.target.value })} />
                    </div>
                    <div>
                      <label className={labelClass}>Témoin 2 — CIN</label>
                      <input type="text" className={inputClass} placeholder="CIN"
                        value={formData.witness2Cin || ''}
                        onChange={(e) => setFormData({ ...formData, witness2Cin: e.target.value })} />
                    </div>
                  </div>
                </div>

                {/* Dot + Régime */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Dot — Mahr (DT)</label>
                    <input type="number" min="0" step="1" className={inputClass} placeholder="Ex: 1000"
                      value={formData.dowry || ''}
                      onChange={(e) => setFormData({ ...formData, dowry: parseFloat(e.target.value) })} />
                  </div>
                  <div>
                    <label className={labelClass}>Régime matrimonial</label>
                    <select className={inputClass}
                      value={formData.regimeOption || 'Séparation de biens'}
                      onChange={(e) => setFormData({ ...formData, regimeOption: e.target.value })}>
                      <option value="Séparation de biens">Séparation de biens</option>
                      <option value="Communauté des biens acquêts">Communauté des biens acquêts (Loi 98-91)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* ─── LOCATION / PRÊT FIELDS ─── */}
            {!isMarriage && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Nombre de Caisses</label>
                  <input type="number" required min="1" className={inputClass}
                    value={formData.nbCaisse}
                    onChange={(e) => setFormData({ ...formData, nbCaisse: parseInt(e.target.value) })} />
                </div>
                <div>
                  <label className={labelClass}>Caution (DT)</label>
                  <input type="number" required step="1" className={inputClass}
                    value={formData.caution}
                    onChange={(e) => setFormData({ ...formData, caution: parseFloat(e.target.value) })} />
                </div>
                <div>
                  <label className={labelClass}>Avance (DT)</label>
                  <input type="number" step="1" className={inputClass}
                    value={formData.avance}
                    onChange={(e) => setFormData({ ...formData, avance: parseFloat(e.target.value) })} />
                </div>
                <div></div>
                <div>
                  <label className={labelClass}>Date de début</label>
                  <input type="date" required className={inputClass}
                    value={dateDebut}
                    onChange={(e) => setDateDebut(e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>Date de fin</label>
                  <input type="date" required className={inputClass}
                    value={dateFin}
                    onChange={(e) => setDateFin(e.target.value)} />
                </div>
              </div>
            )}

            {/* Email notice */}
            <div className={`border rounded-md p-3 text-sm ${isMarriage ? 'bg-rose-50 border-rose-200 text-rose-700' : 'bg-blue-50 border-blue-200 text-blue-700'}`}>
              📧 Un email sera automatiquement envoyé au client avec un lien pour signer le contrat depuis son mobile.
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-3 pt-4 border-t">
              <button type="button" onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                Annuler
              </button>
              <button type="submit"
                className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${isMarriage ? 'bg-rose-600 hover:bg-rose-700' : 'bg-primary-600 hover:bg-primary-700'}`}>
                {isMarriage ? '💍 Créer le Contrat de Mariage' : '📄 Générer et Envoyer'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddContractModal;
