import React, { useMemo } from 'react';
import { Movement, MovementSale, MovementType, Settings, Room, Location } from '../types';
import LineChart from './LineChart';
import BarChart from './BarChart';
import StatCard from './StatCard';

interface ReportsPageProps {
  movements: Movement[];
  settings: Settings;
  rooms: Room[];
  locations: Location[];
}

const ReportsPage: React.FC<ReportsPageProps> = ({ movements, settings, rooms, locations }) => {
  const chartData = useMemo(() => {
    try {
        const salesMonthlyMap: Map<string, { label: string, total: number }> = new Map();
        const locationsMonthlyMap: Map<string, { label: string, total: number }> = new Map();

        movements.forEach(m => {
            const dateObj = new Date(m.date);
            if (isNaN(dateObj.getTime())) return;

            const monthKey = dateObj.toISOString().substring(0, 7); // YYYY-MM
            const monthLabel = dateObj.toLocaleDateString('fr-FR', { year: 'numeric', month: 'short' });
            
            if (m.type === MovementType.Sale) {
                const montant = Number((m as any).montantTotal) || 0;
                const cur = salesMonthlyMap.get(monthKey) || { label: monthLabel, total: 0 };
                cur.total += montant;
                salesMonthlyMap.set(monthKey, cur);
            }
            if (m.type === MovementType.LocationOut) {
                const loyer = Number((m as any).loyer) || 0;
                const cur = locationsMonthlyMap.get(monthKey) || { label: monthLabel, total: 0 };
                cur.total += loyer;
                locationsMonthlyMap.set(monthKey, cur);
            }
        });

        const sortedSalesMonths = Array.from(salesMonthlyMap.entries()).sort(([a], [b]) => a.localeCompare(b));
        const sortedLocationsMonths = Array.from(locationsMonthlyMap.entries()).sort(([a], [b]) => a.localeCompare(b));

        const salesRevenueData = {
            labels: sortedSalesMonths.map(([, info]) => info.label),
            datasets: [{
                label: `CA Ventes (${settings.currencySymbol})`,
                data: sortedSalesMonths.map(([, info]) => info.total),
                color: '#3b82f6'
            }]
        };

        const locationsRevenueData = {
            labels: sortedLocationsMonths.map(([, info]) => info.label),
            datasets: [{
                label: `CA Locations (${settings.currencySymbol})`,
                data: sortedLocationsMonths.map(([, info]) => info.total),
                color: '#16a34a'
            }]
        };

        // Room Occupancy
        const roomCrates: Record<string, number> = {};
        (rooms || []).forEach(r => roomCrates[r.nom || 'Sans nom'] = 0);
        (locations || []).filter(l => l.status === 'En cours').forEach(l => {
            const room = (rooms || []).find(r => r.id === l.roomId);
            if (room) {
                const name = room.nom || 'Sans nom';
                roomCrates[name] = (roomCrates[name] || 0) + (Number(l.nbCaisse) || 0);
            }
        });

        const roomOccupancyData = {
            labels: Object.keys(roomCrates),
            datasets: [{
                label: 'Occupation (Caisses)',
                data: Object.values(roomCrates),
                color: '#10b981'
            }]
        };

        const reportStats = {
            totalSalesRevenue: Array.from(salesMonthlyMap.values()).reduce((sum, v) => sum + v.total, 0),
            totalLocationsRevenue: Array.from(locationsMonthlyMap.values()).reduce((sum, v) => sum + v.total, 0),
            totalCratesInStock: locations.filter(l => l.status === 'En cours').reduce((sum, l) => sum + (Number(l.nbCaisse) || 0), 0),
            activeLocations: locations.filter(l => l.status === 'En cours').length
        };

        return { 
            salesRevenueData,
            locationsRevenueData,
            roomOccupancyData,
            reportStats
        };
    } catch (err) {
        console.error("Erreur calcul rapports:", err);
        return null;
    }
  }, [movements, rooms, locations, settings.currencySymbol]);

  if (!chartData) {
    return <div className="p-10 text-center text-red-500 font-bold">Erreur lors de la génération des rapports. Veuillez vérifier vos données.</div>;
  }


  return (
    <div className="space-y-8 pb-8">
       <div>
            <h1 className="text-2xl font-bold text-gray-800">Rapports d'Activité</h1>
            <p className="text-sm text-gray-500 font-medium">Analyse approfondie de vos performances commerciales et logistiques.</p>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total CA Ventes" value={`${Math.round(chartData.reportStats.totalSalesRevenue).toLocaleString('fr-FR')} ${settings.currencySymbol}`} icon="cash" />
          <StatCard title="Total CA Locations" value={`${Math.round(chartData.reportStats.totalLocationsRevenue).toLocaleString('fr-FR')} ${settings.currencySymbol}`} icon="cash" />
          <StatCard title="Caisses en stock" value={chartData.reportStats.totalCratesInStock.toString()} icon="box" />
          <StatCard title="Contrats actifs" value={chartData.reportStats.activeLocations.toString()} icon="users" />
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <BarChart title={`Chiffre d'affaire pour ventes (${settings.currencySymbol})`} data={chartData.salesRevenueData} />
            <BarChart title={`Chiffre d'affaire pour locations (${settings.currencySymbol})`} data={chartData.locationsRevenueData} />
            <div className="lg:col-span-2">
                <BarChart title="Occupation des chambres (Caisses)" data={chartData.roomOccupancyData} />
            </div>
       </div>
    </div>
  );
};

export default ReportsPage;