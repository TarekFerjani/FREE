require('dotenv').config(); 
const express = require('express');
const cors = require('cors');
const pool = require('./db'); 

const app = express();
const port = process.env.PORT || 3001;

// Autoriser toutes les origines (CORS ouvert)
app.use(cors()); 

// Autoriser JSON dans les requêtes
app.use(express.json({ limit: '10mb' })); 

// Importer les routes
const authRoutes = require('./routes/auth');
const clientRoutes = require('./routes/clients');
const productRoutes = require('./routes/products');
const roomRoutes = require('./routes/rooms');
const movementRoutes = require('./routes/movements');
const locationRoutes = require('./routes/locations');
const invoiceRoutes = require('./routes/invoices');
const contractsRoutes = require('./routes/contracts');
const settingsRoutes = require('./routes/settings');


// Utiliser les routes avec le préfixe /api
app.use('/api', authRoutes); 
app.use('/api/clients', clientRoutes);
app.use('/api/products', productRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/movements', movementRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/contracts', contractsRoutes);
app.use('/api/settings', settingsRoutes);


// Démarrage du serveur
const startServer = async () => {
  let client;
  try {
    client = await pool.connect();
    console.log('✓ Connexion à la base de données réussie.');
    
    // Auto-migration pour la signature du contrat
    try {
      console.log('Vérification du schéma de la table contracts...');
      
      // Vérifier si la colonne signature existe
      const sigResult = await client.query(
        `SELECT column_name FROM information_schema.columns 
         WHERE table_name='contracts' AND column_name='signature'`
      );
      
      if (sigResult.rows.length === 0) {
        await client.query('ALTER TABLE contracts ADD COLUMN signature TEXT');
        console.log('Colonne "signature" ajoutée à la table contracts.');
      } else {
        console.log('Colonne "signature" vérifiée.');
      }
      
      // Migration pour signedAt (horodatage de signature)
      const signedResult = await client.query(
        `SELECT column_name FROM information_schema.columns 
         WHERE table_name='contracts' AND column_name='signedAt'`
      );
      
      if (signedResult.rows.length === 0) {
        await client.query('ALTER TABLE contracts ADD COLUMN "signedAt" TIMESTAMP NULL');
        console.log('Colonne "signedAt" ajoutée à la table contracts.');
      }
      
      // Migration pour la traçabilité des mouvements - updatedAt
      const updatedAtResult = await client.query(
        `SELECT column_name FROM information_schema.columns 
         WHERE table_name='movements' AND column_name='updatedAt'`
      );
      
      if (updatedAtResult.rows.length === 0) {
        await client.query('ALTER TABLE movements ADD COLUMN "updatedAt" TIMESTAMP NULL');
        console.log('Colonne "updatedAt" ajoutée à la table movements.');
      }
      
      // Migration pour la traçabilité des mouvements - updatedBy
      const updatedByResult = await client.query(
        `SELECT column_name FROM information_schema.columns 
         WHERE table_name='movements' AND column_name='updatedBy'`
      );
      
      if (updatedByResult.rows.length === 0) {
        await client.query('ALTER TABLE movements ADD COLUMN "updatedBy" VARCHAR(255) NULL');
        console.log('Colonne "updatedBy" ajoutée à la table movements.');
      }
      
      // Auto-migration pour les permissions par utilisateur
      const permResult = await client.query(
        `SELECT column_name FROM information_schema.columns 
         WHERE table_name='users' AND column_name='permissions'`
      );
      
      if (permResult.rows.length === 0) {
        await client.query('ALTER TABLE users ADD COLUMN permissions TEXT');
        console.log('Colonne "permissions" ajoutée à la table users.');
        
        // Populate default permissions for user role
        const defaultPerms = JSON.stringify({
            dashboard: true,
            clients: true,
            products: true,
            rooms: true,
            stock: true,
            factures: false,
            contrats: false,
            reports: false
        });
        await client.query("UPDATE users SET permissions = $1 WHERE role = 'user'", [defaultPerms]);
        console.log('Permissions par défaut attribuées aux utilisateurs existants.');
      }

      // Auto-migration pour les colonnes du contrat de mariage
      const marriageColumns = [
        { name: 'husbandName', type: 'TEXT' },
        { name: 'husbandCin', type: 'VARCHAR(50)' },
        { name: 'husbandDob', type: 'VARCHAR(50)' },
        { name: 'husbandEmail', type: 'VARCHAR(255)' },
        { name: 'wifeName', type: 'TEXT' },
        { name: 'wifeCin', type: 'VARCHAR(50)' },
        { name: 'wifeDob', type: 'VARCHAR(50)' },
        { name: 'wifeEmail', type: 'VARCHAR(255)' },
        { name: 'witness1Name', type: 'TEXT' },
        { name: 'witness1Cin', type: 'VARCHAR(50)' },
        { name: 'witness2Name', type: 'TEXT' },
        { name: 'witness2Cin', type: 'VARCHAR(50)' },
        { name: 'dowry', type: 'DECIMAL(10,2)' },
        { name: 'regimeOption', type: 'VARCHAR(255)' },
        { name: 'husbandSignature', type: 'TEXT' },
        { name: 'wifeSignature', type: 'TEXT' },
        { name: 'husbandSignedAt', type: 'TIMESTAMP' },
        { name: 'wifeSignedAt', type: 'TIMESTAMP' }
      ];

      for (const col of marriageColumns) {
        const colCheck = await client.query(
          `SELECT column_name FROM information_schema.columns 
           WHERE table_name='contracts' AND column_name=$1`,
          [col.name]
        );
        if (colCheck.rows.length === 0) {
          await client.query(`ALTER TABLE contracts ADD COLUMN "${col.name}" ${col.type}`);
          console.log(`Colonne "${col.name}" ajoutée à la table contracts.`);
        }
      }

      // Gérer la valeur 'Mariage' : supprimer contrainte CHECK et/ou ajouter à l'enum
      try {
        // 1. Supprimer toutes les contraintes CHECK sur la colonne 'type' de contracts
        const checkResult = await client.query(`
          SELECT con.conname
          FROM pg_constraint con
          JOIN pg_class rel ON rel.oid = con.conrelid
          WHERE rel.relname = 'contracts' AND con.contype = 'c'
            AND pg_get_constraintdef(con.oid) LIKE '%type%'
        `);
        for (const row of checkResult.rows) {
          await client.query(`ALTER TABLE contracts DROP CONSTRAINT IF EXISTS "${row.conname}"`);
          console.log('Contrainte CHECK "' + row.conname + '" supprimée pour permettre Mariage.');
        }

        // 2. Si la colonne type est un ENUM, ajouter 'Mariage'
        const typeColResult = await client.query(
          `SELECT data_type, udt_name FROM information_schema.columns
           WHERE table_name='contracts' AND column_name='type'`
        );
        if (typeColResult.rows.length > 0) {
          const colInfo = typeColResult.rows[0];
          if (colInfo.data_type === 'USER-DEFINED') {
            try {
              await client.query(`ALTER TYPE "${colInfo.udt_name}" ADD VALUE IF NOT EXISTS 'Mariage'`);
              console.log('Valeur Mariage ajoutée à l\'enum ' + colInfo.udt_name);
            } catch (enumErr) {
              console.log('Note enum: ' + enumErr.message);
            }
          } else {
            // VARCHAR/TEXT : recréer la contrainte en incluant Mariage
            await client.query(`
              ALTER TABLE contracts DROP CONSTRAINT IF EXISTS contracts_type_check
            `);
            await client.query(`
              ALTER TABLE contracts ADD CONSTRAINT contracts_type_check
                CHECK (type IN ('Location', 'Prêt de caisses', 'Mariage'))
            `);
            console.log('Contrainte contracts_type_check mise à jour avec Mariage.');
          }
        }
      } catch (constraintErr) {
        console.log('Note contrainte type: ' + constraintErr.message);
      }
    } catch (migError) {
      console.error('Erreur lors de la migration automatique:', migError.message);
    }
    
    client.release();

    app.listen(port, () => {
      console.log(`✓ Backend server running on http://localhost:${port}`);
    });
  } catch (error) {
    if (client) client.release();
    console.error('*******************************************************************************');
    console.error('* ERREUR FATALE : Impossible de se connecter à la base de données.');
    console.error(`* Erreur: ${error.message}`);
    console.error('* Vérifiez votre configuration PostgreSQL dans .env');
    console.error('* PostgreSQL doit être exécuté sur:', process.env.DB_HOST || 'localhost');
    console.error('* Port:', process.env.DB_PORT || 5432);
    console.error('* Base de données:', process.env.DB_DATABASE || 'frigo_db');
    console.error('*******************************************************************************');
    process.exit(1);
  }
};

startServer();
