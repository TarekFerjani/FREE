const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('../db');
const { sendContractEmail } = require('../utils/mailer');
const router = express.Router();

// Helper: normalise une ligne contracts (PostgreSQL retourne certaines colonnes en minuscules)
function mapContract(row) {
    if (!row) return null;
    return {
        id:               row.id,
        date:             row.date,
        clientId:         row.clientid         ?? row.clientId,
        type:             row.type,
        nbCaisse:         Number(row.nbcaisse  ?? row.nbCaisse  ?? 0),
        caution:          Number(row.caution   ?? 0),
        avance:           Number(row.avance    ?? 0),
        periode:          row.periode,
        signature:        row.signature        ?? null,
        signedAt:         row.signedat         ?? row.signedAt         ?? null,
        status:           row.status,
        husbandName:      row.husbandname      ?? row.husbandName      ?? null,
        husbandCin:       row.husbandcin       ?? row.husbandCin       ?? null,
        husbandDob:       row.husbanddob       ?? row.husbandDob       ?? null,
        husbandEmail:     row.husbandemail     ?? row.husbandEmail     ?? null,
        wifeName:         row.wifename         ?? row.wifeName         ?? null,
        wifeCin:          row.wifecin          ?? row.wifeCin          ?? null,
        wifeDob:          row.wifedob          ?? row.wifeDob          ?? null,
        wifeEmail:        row.wifeemail        ?? row.wifeEmail        ?? null,
        witness1Name:     row.witness1name     ?? row.witness1Name     ?? null,
        witness1Cin:      row.witness1cin      ?? row.witness1Cin      ?? null,
        witness2Name:     row.witness2name     ?? row.witness2Name     ?? null,
        witness2Cin:      row.witness2cin      ?? row.witness2Cin      ?? null,
        dowry:            row.dowry != null ? Number(row.dowry) : null,
        regimeOption:     row.regimeoption     ?? row.regimeOption     ?? null,
        husbandSignature: row.husbandsignature ?? row.husbandSignature ?? null,
        wifeSignature:    row.wifesignature    ?? row.wifeSignature    ?? null,
        husbandSignedAt:  row.husbandsignedat  ?? row.husbandSignedAt  ?? null,
        wifeSignedAt:     row.wifesignedat     ?? row.wifeSignedAt     ?? null,
    };
}

// GET all contracts
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM contracts ORDER BY date DESC');
        res.json(result.rows.map(mapContract));
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// TEMP: Fix type constraint to allow 'Mariage' — call once: GET /api/contracts/fix-type-constraint
router.get('/fix-type-constraint', async (req, res) => {
    try {
        // Drop all CHECK constraints on the type column
        const checks = await pool.query(`
            SELECT con.conname FROM pg_constraint con
            JOIN pg_class rel ON rel.oid = con.conrelid
            WHERE rel.relname = 'contracts' AND con.contype = 'c'
              AND pg_get_constraintdef(con.oid) LIKE '%type%'
        `);
        const dropped = [];
        for (const row of checks.rows) {
            await pool.query(`ALTER TABLE contracts DROP CONSTRAINT IF EXISTS "${row.conname}"`);
            dropped.push(row.conname);
        }
        // Re-create with Mariage included
        await pool.query(`ALTER TABLE contracts DROP CONSTRAINT IF EXISTS contracts_type_check`);
        await pool.query(`ALTER TABLE contracts ADD CONSTRAINT contracts_type_check 
            CHECK (type IN ('Location', 'Prêt de caisses', 'Mariage'))`);
        res.json({ success: true, message: 'Contrainte mise à jour. Mariage est maintenant autorisé.', dropped });
    } catch (err) {
        // Maybe it's an enum type
        try {
            const typeInfo = await pool.query(
                `SELECT udt_name FROM information_schema.columns WHERE table_name='contracts' AND column_name='type'`
            );
            if (typeInfo.rows.length > 0) {
                await pool.query(`ALTER TYPE "${typeInfo.rows[0].udt_name}" ADD VALUE IF NOT EXISTS 'Mariage'`);
                return res.json({ success: true, message: 'Valeur Mariage ajoutée à l\'enum.' });
            }
        } catch (e2) {}
        res.status(500).json({ error: err.message });
    }
});

// DEBUG: Get contracts schema info
router.get('/debug-schema', async (req, res) => {
    try {
        const columns = await pool.query(`
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'contracts'
        `);
        const constraints = await pool.query(`
            SELECT con.conname, pg_get_constraintdef(con.oid) as def
            FROM pg_constraint con
            JOIN pg_class rel ON rel.oid = con.conrelid
            WHERE rel.relname = 'contracts'
        `);
        res.json({ columns: columns.rows, constraints: constraints.rows });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// POST new contract
router.post('/', async (req, res) => {
    const {
        clientId, type, nbCaisse, caution, avance, periode, signature,
        husbandName, husbandCin, husbandDob, husbandEmail,
        wifeName, wifeCin, wifeDob, wifeEmail,
        witness1Name, witness1Cin,
        witness2Name, witness2Cin,
        dowry, regimeOption
    } = req.body;

    const isMarriage = type === 'Mariage';

    if (!clientId || !type) {
        return res.status(400).json({ message: 'Champs requis manquants : clientId et type sont obligatoires.' });
    }
    if (!isMarriage && (!nbCaisse || caution === undefined || !periode)) {
        return res.status(400).json({ message: 'Champs requis manquants pour un contrat de location/prêt.' });
    }
    if (isMarriage && (!husbandName || !wifeName)) {
        return res.status(400).json({ message: 'Les noms de l\'époux et de l\'épouse sont obligatoires.' });
    }

    const id = uuidv4();
    const date = new Date();
    const signedAt = signature ? new Date() : null;
    const status = signature ? 'Actif' : 'En attente';
    const finalNbCaisse = isMarriage ? 1 : (nbCaisse || 1);
    const finalCaution = isMarriage ? 0 : (caution || 0);
    const finalAvance = isMarriage ? 0 : (avance || 0);
    const finalPeriode = isMarriage ? (periode || new Date().toLocaleDateString('fr-TN')) : periode;

    try {
        const clientResult = await pool.query('SELECT nom, prenom, email FROM clients WHERE id = $1', [clientId]);
        const client = clientResult.rows[0];
        if (!client) {
            return res.status(400).json({ message: 'Client introuvable.' });
        }

        // Fix contrainte CHECK si elle bloque 'Mariage'
        if (isMarriage) {
            try {
                await pool.query(`ALTER TABLE contracts DROP CONSTRAINT IF EXISTS contracts_type_check`);
                await pool.query(`ALTER TABLE contracts ADD CONSTRAINT contracts_type_check CHECK (type IN ('Location', 'Prêt de caisses', 'Mariage'))`);
            } catch (cErr) {
                try { await pool.query(`ALTER TYPE contracts_type ADD VALUE IF NOT EXISTS 'Mariage'`); } catch (e2) {}
            }
        }

        // Détecter si la colonne est stockée en camelCase ou lowercase
        const colCheck = await pool.query(
            `SELECT column_name FROM information_schema.columns WHERE table_name='contracts' AND column_name IN ('clientId','clientid') LIMIT 1`
        );
        const clientIdCol = colCheck.rows.length > 0 ? colCheck.rows[0].column_name : 'clientid';
        const nbCaisseCol = clientIdCol === 'clientId' ? '"nbCaisse"' : 'nbcaisse';
        const signedAtCol = clientIdCol === 'clientId' ? '"signedAt"' : 'signedat';
        const clientIdSql = clientIdCol === 'clientId' ? '"clientId"' : 'clientid';

        await pool.query(
            `INSERT INTO contracts (
                id, date, ${clientIdSql}, type, ${nbCaisseCol}, caution, avance, periode, signature, ${signedAtCol}, status,
                "husbandName", "husbandCin", "husbandDob", "husbandEmail",
                "wifeName", "wifeCin", "wifeDob", "wifeEmail",
                "witness1Name", "witness1Cin",
                "witness2Name", "witness2Cin",
                dowry, "regimeOption"
            ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
            [
                id, date, clientId, type, finalNbCaisse, finalCaution, finalAvance, finalPeriode,
                signature || null, signedAt, status,
                husbandName || null, husbandCin || null, husbandDob || null, husbandEmail || null,
                wifeName || null, wifeCin || null, wifeDob || null, wifeEmail || null,
                witness1Name || null, witness1Cin || null,
                witness2Name || null, witness2Cin || null,
                dowry || null, regimeOption || null
            ]
        );

        // Récupérer les settings
        const settingsResult = await pool.query('SELECT * FROM settings LIMIT 1');
        const company = settingsResult.rows[0] || {};
        const companyName = company.companyname ?? company.companyName ?? 'Frigo App';
        const companyEmail = company.companyemail ?? company.companyEmail ?? process.env.EMAIL_USER;

        if (isMarriage) {
            if (husbandEmail) {
                try { await sendContractEmail(husbandEmail, id, husbandName, companyName, companyEmail); }
                catch (e) { console.error('Email époux failed:', e.message); }
            }
            if (wifeEmail) {
                try { await sendContractEmail(wifeEmail, id, wifeName, companyName, companyEmail); }
                catch (e) { console.error('Email épouse failed:', e.message); }
            }
            if (client && client.email) {
                try { await sendContractEmail(client.email, id, `${husbandName} & ${wifeName}`, companyName, companyEmail); }
                catch (e) { console.error('Email client failed:', e.message); }
            }
        } else {
            if (client && client.email) {
                try { await sendContractEmail(client.email, id, `${client.prenom} ${client.nom}`, companyName, companyEmail); }
                catch (e) { console.error('Failed to send auto-email:', e.message); }
            }
        }

        res.status(201).json({ id, date, clientId, type, status });
    } catch (error) {
        console.error('Erreur création contrat:', error);
        res.status(500).json({ message: error.message });
    }
});

// PUT update contract status and signature
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { status, signature } = req.body;
        
        let query = 'UPDATE contracts SET status = $1';
        const params = [status];
        
        if (signature) {
            query += ', signature = $2, signedAt = $3';
            params.push(signature);
            params.push(new Date());
        }

        const paramIndex = params.length + 1;
        query += ` WHERE id = $${paramIndex}`;
        params.push(id);
        
        await pool.query(query, params);
        res.json({ id, status, signature: !!signature });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// DELETE contract
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await pool.query('DELETE FROM contracts WHERE id = $1', [id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.post('/send/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Fetch contract and client info (clientid en minuscules dans PostgreSQL)
        const contractsResult = await pool.query(`
            SELECT c.*, cl.email, cl.nom, cl.prenom 
            FROM contracts c 
            JOIN clients cl ON c.clientid = cl.id 
            WHERE c.id = $1`, [id]);
        const contracts = contractsResult.rows;
        
        if (contracts.length === 0) return res.status(404).json({ message: 'Contrat non trouvé' });
        
        const contract = contracts[0];
        if (!contract.email) return res.status(400).json({ message: 'Le client n\'a pas d\'adresse email' });

        // Fetch company settings for branding
        const settingsResult = await pool.query('SELECT companyname, companyemail FROM settings LIMIT 1');
        const company = settingsResult.rows[0] || {};
        const companyName = company.companyname ?? 'Frigo App';
        const companyEmail = company.companyemail ?? process.env.EMAIL_USER;

        await sendContractEmail(
            contract.email,
            contract.id,
            `${contract.prenom} ${contract.nom}`,
            companyName,
            companyEmail
        );
        res.json({ success: true });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: error.message });
    }
});

// GET contract for public signing (no auth required)
router.get('/public/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const rowsResult = await pool.query(`
            SELECT 
                c.*,
                s.companyname AS "companyName",
                s.currencysymbol AS "currencySymbol",
                s.companyaddress AS "companyAddress",
                s.companyphone AS "companyPhone",
                s.fiscalid AS "fiscalId",
                s.companylogo AS "companyLogo",
                s.companysignature AS "companySignature",
                s.companyemail AS "settingsEmail",
                cl.email as "clientEmail", cl.nom as "clientNom", cl.prenom as "clientPrenom", cl.cin as "clientCin"
            FROM contracts c
            LEFT JOIN settings s ON s.id = 1
            JOIN clients cl ON c.clientid = cl.id
            WHERE c.id = $1`, [id]);
        const rows = rowsResult.rows;
        if (rows.length === 0) return res.status(404).json({ message: 'Non trouvé' });
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// PUT signature for public signing (no auth required)
router.put('/public/:id/sign', async (req, res) => {
    try {
        const { id } = req.params;
        const { signature, role } = req.body;

        if (!signature) {
            return res.status(400).json({ message: 'Signature requise' });
        }

        // 1. Fetch current contract details first to check the type
        const checkResult = await pool.query('SELECT type, "husbandSignature", "wifeSignature" FROM contracts WHERE id = $1', [id]);
        if (checkResult.rows.length === 0) {
            return res.status(404).json({ message: 'Contrat non trouvé' });
        }
        const contractType = checkResult.rows[0].type;
        const isMarriage = contractType === 'Mariage';

        const signedAt = new Date();
        let query = '';
        let params = [];

        if (isMarriage) {
            if (role === 'husband') {
                query = 'UPDATE contracts SET "husbandSignature" = $1, "husbandSignedAt" = $2 WHERE id = $3';
                params = [signature, signedAt, id];
            } else if (role === 'wife') {
                query = 'UPDATE contracts SET "wifeSignature" = $1, "wifeSignedAt" = $2 WHERE id = $3';
                params = [signature, signedAt, id];
            } else {
                return res.status(400).json({ message: 'Rôle de signature invalide (doit être husband ou wife)' });
            }
        } else {
            query = 'UPDATE contracts SET signature = $1, "signedAt" = $2, status = $3 WHERE id = $4';
            params = [signature, signedAt, 'Actif', id];
        }

        await pool.query(query, params);

        // 2. For marriage, check if both have signed before updating status and sending email
        if (isMarriage) {
            const doubleCheck = await pool.query(
                'SELECT "husbandSignature", "wifeSignature" FROM contracts WHERE id = $1',
                [id]
            );
            const { husbandSignature, wifeSignature } = doubleCheck.rows[0];
            const bothSigned = !!husbandSignature && !!wifeSignature;

            if (!bothSigned) {
                // Return success, but do not send email yet
                return res.json({ success: true, signedAt, status: 'En attente', bothSigned: false });
            }

            // Both have signed! Update overall status and general signature fields
            await pool.query(
                'UPDATE contracts SET status = $1, signature = $2, "signedAt" = $3 WHERE id = $4',
                ['Actif', husbandSignature, signedAt, id]
            );
        }

        // 3. Send confirmation email with PDF attachment (only when fully signed)
        try {
            const rowsResult = await pool.query(`
                SELECT cc.*, 
                       cl.email as clientEmail, cl.nom, cl.prenom, cl.cin,
                       s.companyName, s.companyEmail, s.companyAddress,
                       s.companyPhone, s.fiscalId, s.currencySymbol, s.companyLogo, s.companySignature
                FROM contracts cc
                JOIN clients cl ON cc.clientId = cl.id
                LEFT JOIN settings s ON s.id = 1
                WHERE cc.id = $1`, [id]);

            const c = rowsResult.rows[0];
            const { sendSignedContractEmail } = require('../utils/mailer');
            const fs = require('fs');
            const company = c.companyName || "L'entreprise";
            const refId = id.substring(0, 8).toUpperCase();

            let pdfBuffer;
            try {
                if (isMarriage) {
                    const { generateMarriagePdf } = require('../utils/marriagePdfGenerator');
                    pdfBuffer = await generateMarriagePdf(c, c.husbandSignature, c.wifeSignature);
                } else {
                    const { generateContractPdf } = require('../utils/pdfGenerator');
                    pdfBuffer = await generateContractPdf(c, signature);
                }
                fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] PDF generated (${c.type}), size: ${pdfBuffer.length}\n`);
            } catch (pdfErr) {
                fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] PDF ERROR: ${pdfErr.message}\n`);
                throw pdfErr;
            }

            const makeHtmlBody = (name) => `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"/>
<style>body{font-family:Arial,sans-serif;background:#f8fafc;margin:0;padding:30px}
.card{max-width:560px;margin:auto;background:#fff;border-radius:12px;padding:32px 36px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h2{color:${isMarriage ? '#7c3aed' : '#1e40af'};margin:0 0 16px;font-size:18px}
p{color:#334155;font-size:14px;line-height:1.6;margin:0 0 12px}
.ft{margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:11px;color:#94a3b8}
</style></head><body><div class="card">
<h2>${isMarriage ? '💍 Votre Contrat de Mariage Signé' : '✅ Votre Contrat Signé'} — ${company}</h2>
<p>Bonjour <strong>${name}</strong>,</p>
<p>${isMarriage ? 'L\'acte de mariage a été signé électroniquement. Vous trouverez le contrat officiel bilingue en pièce jointe.' : 'Votre contrat a bien été signé électroniquement. Vous trouverez votre exemplaire en pièce jointe PDF.'}</p>
<p>Cordialement,<br/><strong>${company}</strong></p>
<div class="ft">${c.companyAddress || ''} &nbsp;•&nbsp; Tél: ${c.companyPhone || ''}</div>
</div></body></html>`;

            if (isMarriage) {
                // Envoyer à l'époux
                if (c.husbandemail || c.husbandEmail) {
                    const email = c.husbandemail || c.husbandEmail;
                    try {
                        await sendSignedContractEmail(email, id, c.husbandname || c.husbandName, company, c.companyEmail, makeHtmlBody(c.husbandname || c.husbandName), pdfBuffer, refId);
                        fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ✅ Email époux: ${email}\n`);
                    } catch (e) { fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ❌ Email époux: ${e.message}\n`); }
                }
                // Envoyer à l'épouse
                if (c.wifeemail || c.wifeEmail) {
                    const email = c.wifeemail || c.wifeEmail;
                    try {
                        await sendSignedContractEmail(email, id, c.wifename || c.wifeName, company, c.companyEmail, makeHtmlBody(c.wifename || c.wifeName), pdfBuffer, refId);
                        fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ✅ Email épouse: ${email}\n`);
                    } catch (e) { fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ❌ Email épouse: ${e.message}\n`); }
                }
                // Aussi au client responsable
                if (c.clientEmail) {
                    const name = `${c.husbandname || c.husbandName || ''} & ${c.wifename || c.wifeName || ''}`;
                    try {
                        await sendSignedContractEmail(c.clientEmail, id, name, company, c.companyEmail, makeHtmlBody(name), pdfBuffer, refId);
                        fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ✅ Email client: ${c.clientEmail}\n`);
                    } catch (e) { fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ❌ Email client: ${e.message}\n`); }
                }
            } else if (c.clientEmail) {
                const name = `${c.prenom || ''} ${c.nom || ''}`.trim();
                try {
                    await sendSignedContractEmail(c.clientEmail, id, name, company, c.companyEmail, makeHtmlBody(name), pdfBuffer, refId);
                    fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ✅ Email sent to ${c.clientEmail}\n`);
                } catch (e) { fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ❌ Email: ${e.message}\n`); }
            } else {
                fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] ⚠️ No email for contract ${id}\n`);
            }
        } catch (emailErr) {
            const fs = require('fs');
            fs.appendFileSync('email_debug.log', `[${new Date().toISOString()}] FATAL: ${emailErr.message}\n`);
            console.error('[EMAIL] Error:', emailErr.message);
        }

        res.json({ success: true, signedAt, status });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
