const { Pool } = require('pg');

// Primary configuration from environment
const primaryConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    database: process.env.DB_DATABASE || 'frigo_db',
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
};

// Fallback local config to help local development when remote DB is unreachable
const fallbackConfig = {
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: 'postgres',
    database: 'frigo_db',
    max: 5,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
};

let pool = new Pool(primaryConfig);

// Proxy object exported so modules keep using the same reference even if we replace the underlying pool
const proxy = {
    query: (...args) => pool.query(...args),
    connect: (...args) => pool.connect(...args),
    on: (...args) => pool.on(...args),
    end: (...args) => pool.end(...args),
};

// Try primary connection; if it fails, try fallback and keep proxy working
(async function ensureConnection() {
    try {
        await pool.query('SELECT 1');
        console.log('DB: Connected to primary PostgreSQL host:', primaryConfig.host);
    } catch (err) {
        console.warn('DB: Primary connection failed:', err.message);
        console.warn('DB: Attempting fallback localhost PostgreSQL...');
        try {
            pool = new Pool(fallbackConfig);
            await pool.query('SELECT 1');
            console.log('DB: Connected to fallback PostgreSQL at localhost');
        } catch (err2) {
            console.error('DB: Fallback connection failed:', err2.message);
            console.error('DB: The application may not function correctly without a reachable database.');
        }
    }
})();

pool.on && pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
});

module.exports = proxy;