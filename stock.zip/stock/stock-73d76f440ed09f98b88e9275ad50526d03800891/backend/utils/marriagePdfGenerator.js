const puppeteer = require('puppeteer');
const QRCode = require('qrcode');

// ─── Marriage contract PDF generator ────────────────────────────────────────
async function generateMarriagePdf(c, husbandSignature, wifeSignature) {
    const company   = c.companyName || 'Frigo Inc.';
    const address   = c.companyAddress || '';
    const phone     = c.companyPhone || '';
    const dateStr   = new Date(c.date).toLocaleDateString('fr-TN');
    const dateArStr = new Date(c.date).toLocaleDateString('ar-TN');
    const refId     = c.id.substring(0, 8).toUpperCase();
    
    // Check signatures
    const hSig = husbandSignature || c.husbandSignature || c.husband_signature;
    const wSig = wifeSignature || c.wifeSignature || c.wife_signature;
    const isSigned = !!hSig && !!wSig;
    const signedAtStr = new Date().toLocaleString('fr-TN');
    
    const verifyUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/sign/${c.id}`;
    const qrDataUrl = await QRCode.toDataURL(verifyUrl, { width: 80, margin: 1 });

    const dowry   = c.dowry ? `${Math.round(c.dowry).toLocaleString('fr-FR')} DT` : 'Non stipulée';
    const regime  = c.regimeOption || 'Séparation de biens';
    const regimeAr = regime.includes('Communauté') ? 'نظام الاشتراك في الأموال المكتسبة (القانون 98-91)' : 'الفصل في الأملاك';

    const witness1 = c.witness1Name ? `${c.witness1Name}${c.witness1Cin ? ' — CIN: ' + c.witness1Cin : ''}` : '-';
    const witness2 = c.witness2Name ? `${c.witness2Name}${c.witness2Cin ? ' — CIN: ' + c.witness2Cin : ''}` : '-';
    const witness1Ar = c.witness1Name ? `${c.witness1Name}${c.witness1Cin ? ' — هوية: ' + c.witness1Cin : ''}` : '-';
    const witness2Ar = c.witness2Name ? `${c.witness2Name}${c.witness2Cin ? ' — هوية: ' + c.witness2Cin : ''}` : '-';

    const logoTag  = c.companyLogo ? `<img src="${c.companyLogo}" class="watermark" />` : '';
    const husbandSignTag = hSig ? `<img src="${hSig}" style="max-height:50px;"/>` : '<div style="height:50px;"></div>';
    const wifeSignTag = wSig ? `<img src="${wSig}" style="max-height:50px;"/>` : '<div style="height:50px;"></div>';
    const coSignTag = c.companySignature ? `<img src="${c.companySignature}" style="max-height:50px;"/>` : '<div style="height:50px;"></div>';

    const stampFr = isSigned
        ? `<div class="stamp"><img src="${qrDataUrl}" style="width:65px;height:65px;"/><div>✅ <strong>Acte signé électroniquement</strong><br/>Horodatage : ${signedAtStr}<br/>Réf : ${refId}</div></div>`
        : `<div class="stamp"><img src="${qrDataUrl}" style="width:65px;height:65px;"/><div>⏳ <strong>En attente de signatures</strong><br/>Scannez le QR code pour signer.<br/>Réf : ${refId}</div></div>`;

    const stampAr = isSigned
        ? `<div class="stamp" style="flex-direction:row-reverse;text-align:right;"><img src="${qrDataUrl}" style="width:65px;height:65px;"/><div>✅ <strong>وثيقة موقّعة إلكترونياً</strong><br/>التاريخ: ${signedAtStr}<br/>المرجع: ${refId}</div></div>`
        : `<div class="stamp" style="flex-direction:row-reverse;text-align:right;"><img src="${qrDataUrl}" style="width:65px;height:65px;"/><div>⏳ <strong>في انتظار التواقيع</strong><br/>امسح الرمز للتوقيع.<br/>المرجع: ${refId}</div></div>`;

    const emblemSvg = `
    <svg viewBox="0 0 100 100" class="national-emblem" style="width: 55px; height: 55px; margin: 0 auto 8px; display: block;">
      <!-- Circles -->
      <circle cx="50" cy="50" r="46" fill="none" stroke="#dc2626" stroke-width="2.5"/>
      <circle cx="50" cy="50" r="42" fill="none" stroke="#dc2626" stroke-width="1" stroke-dasharray="2 2"/>
      
      <!-- Carthage ship silhouette in center -->
      <path d="M30 45 L50 25 L70 45 L62 45 L50 33 L38 45 Z" fill="#dc2626"/>
      <path d="M26 48 h48 L68 56 H32 Z" fill="#dc2626"/>
      <line x1="50" y1="25" x2="50" y2="48" stroke="#dc2626" stroke-width="1.5"/>
      
      <!-- Scales of Justice -->
      <path d="M32 63 h36 M50 56 v18" stroke="#dc2626" stroke-width="2"/>
      <path d="M32 63 v6 M68 63 v6" stroke="#dc2626" stroke-width="2"/>
      <circle cx="32" cy="71" r="3" fill="#dc2626"/>
      <circle cx="68" cy="71" r="3" fill="#dc2626"/>
      
      <!-- Star and Crescent (Top) -->
      <path d="M50 8 A5 5 0 1 0 55 17 A4 4 0 1 1 50 10 Z" fill="#dc2626"/>
      <polygon points="53,9 54,11 56,11 54.5,12 55,14 53.5,13 52,14 52.5,12 51,11 53,11" fill="#dc2626"/>
    </svg>
    `;

    const css = `
    @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Source+Sans+3:wght@400;600;700&display=swap');
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Source Sans 3',serif;color:#111}
    .page{position:relative;width:210mm;min-height:297mm;padding:15mm 20mm;page-break-after:always;display:flex;flex-direction:column;overflow:hidden}
    .page-ar{font-family:'Amiri',serif;direction:rtl}
    .watermark{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);max-width:70%;max-height:70%;opacity:0.05;pointer-events:none;z-index:0}
    .doc-id{position:absolute;left:6mm;bottom:50%;transform:rotate(-90deg);transform-origin:left bottom;font-family:monospace;font-size:7pt;color:#a0aec0;letter-spacing:1px;white-space:nowrap}
    .header{color:#7c3aed;text-align:center;border-bottom:2px solid #7c3aed;padding-bottom:8px;margin-bottom:14px}
    .header h1{font-size:16pt;letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:3px}
    .header .sub{font-size:9pt;color:#6d28d9;font-style:italic;margin-bottom:3px}
    .header .ref{font-size:8pt;color:#64748b}
    .section{margin-bottom:10px}
    .stitle{font-size:9.5pt;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px;border-left:3px solid #7c3aed;padding-left:6px}
    .page-ar .stitle{border-left:none;border-right:3px solid #7c3aed;padding-left:0;padding-right:6px;text-align:right}
    .row{display:flex;gap:10px}
    .col{flex:1}
    .field{margin-bottom:3px;font-size:9pt}
    .field span{font-weight:700;color:#111;font-size:9.5pt}
    .clause{font-size:9pt;line-height:1.5;margin-bottom:4px}
    table.fin{width:100%;border-collapse:collapse;font-size:9pt}
    table.fin td,table.fin th{border:1px solid #c4b5fd;padding:5px 9px}
    table.fin th{background:#ede9fe;font-weight:700;color:#4c1d95}
    .sign-area{display:flex;justify-content:space-between;align-items:center;margin-top:20px;position:relative}
    .sign-box{text-align:center;width:30%;position:relative}
    .sign-line{border-top:1px solid #333;margin-top:35px;padding-top:4px;font-size:8pt}
    
    /* Official Tunisian Republic Wet Notary Stamp */
    .notary-stamp-wrapper{position:absolute;top:-45px;left:50%;transform:translateX(-50%) rotate(-8deg);width:100px;height:100px;pointer-events:none;z-index:10}
    .notary-stamp{width:100%;height:100%;border:3px double #dc2626;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#dc2626;font-family:'Amiri', 'Source Sans 3', sans-serif;opacity:0.85;background:transparent;box-shadow:inset 0 0 4px rgba(220,38,38,0.1)}
    .notary-stamp .title-ar{font-size:6.5pt;font-weight:700;line-height:1.1;text-align:center}
    .notary-stamp .title-fr{font-size:4.5pt;font-weight:700;line-height:1.1;letter-spacing:0.2px}
    .notary-stamp .center-icon{font-size:10pt;margin:1px 0}
    .notary-stamp .type-stamp{font-size:5pt;font-weight:700;border-top:1px dashed #dc2626;border-bottom:1px dashed #dc2626;padding:1px 3px;margin-top:1px}

    .stamp{margin-top:10px;padding:8px 12px;background:#faf5ff;border:1px solid #c4b5fd;border-radius:4px;font-size:8pt;color:#475569;display:flex;align-items:center;gap:12px}
    .stamp strong{color:#1e293b}
    .legal{position:absolute;right:6mm;top:50%;transform:rotate(-90deg);transform-origin:right top;font-size:7pt;color:#94a3b8;white-space:nowrap}
    @media print{@page{margin:0;size:A4}body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{page-break-after:always}}`;

    const html = `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"/><title>Contrat de Mariage ${refId}</title><style>${css}</style></head><body>

<!-- PAGE 1 : FRANÇAIS -->
<div class="page">
${logoTag}
<div class="doc-id">DOC-MARIAGE: ${c.id}</div>
<div style="flex:1">
  ${emblemSvg}
<div class="header">
  <h1>République Tunisienne</h1>
  <div class="sub" style="font-size:10pt;font-weight:700;color:#dc2626;text-transform:uppercase;letter-spacing:1px;font-style:normal;margin-bottom:6px;">Contrat de Mariage Officiel</div>
  <div class="ref">Réf : ${refId} &nbsp;|&nbsp; Notaire : ${company} &nbsp;|&nbsp; Daté du ${dateStr}</div>
</div>

<div class="section">
  <div class="stitle">Art. 1 — Les époux</div>
  <div class="row">
    <div class="col" style="background:#eff6ff;padding:8px;border-radius:6px;">
      <div class="field" style="font-weight:700;color:#1d4ed8;margin-bottom:4px;">♂ L'Époux</div>
      <div class="field">Nom : <span>${c.husbandName || '-'}</span></div>
      <div class="field">CIN : <span>${c.husbandCin || '-'}</span></div>
      <div class="field">Date de naissance : <span>${c.husbandDob || '-'}</span></div>
      ${c.husbandEmail ? `<div class="field">Email : <span>${c.husbandEmail}</span></div>` : ''}
    </div>
    <div class="col" style="background:#fdf2f8;padding:8px;border-radius:6px;">
      <div class="field" style="font-weight:700;color:#be185d;margin-bottom:4px;">♀ L'Épouse</div>
      <div class="field">Nom : <span>${c.wifeName || '-'}</span></div>
      <div class="field">CIN : <span>${c.wifeCin || '-'}</span></div>
      <div class="field">Date de naissance : <span>${c.wifeDob || '-'}</span></div>
      ${c.wifeEmail ? `<div class="field">Email : <span>${c.wifeEmail}</span></div>` : ''}
    </div>
  </div>
</div>

<div class="section">
  <div class="stitle">Art. 2 — Témoins (Art. 32 CSP)</div>
  <table class="fin"><tr><th>Témoin</th><th>Nom complet</th><th>CIN</th></tr>
  <tr><td>1er Témoin</td><td>${witness1}</td><td>${c.witness1Cin || '-'}</td></tr>
  <tr><td>2ème Témoin</td><td>${witness2}</td><td>${c.witness2Cin || '-'}</td></tr>
  </table>
</div>

<div class="section">
  <div class="stitle">Art. 3 — La dot (Mahr) — Art. 12 CSP</div>
  <table class="fin"><tr><th>Désignation</th><th>Montant</th></tr>
  <tr><td>Dot (Mahr — Montant convenu entre les époux)</td><td><strong>${dowry}</strong></td></tr>
  </table>
  <p class="clause" style="margin-top:6px;">La dot constitue un droit exclusif de l'épouse, conformément à l'article 12 du Code du Statut Personnel tunisien.</p>
</div>

<div class="section">
  <div class="stitle">Art. 4 — Régime matrimonial</div>
  <p class="clause">Les époux ont choisi le régime suivant : <strong>${regime}</strong>.<br/>
  ${regime.includes('Communauté') ? 'Ce régime est régi par la loi n° 98-91 du 9 novembre 1998, relative au régime de la communauté des biens acquis entre époux.' : 'Chaque époux conserve l\'administration, la jouissance et la libre disposition de ses biens personnels.'}</p>
</div>

<div class="section">
  <div class="stitle">Art. 5 — Dispositions légales</div>
  <p class="clause">Le présent contrat est établi conformément aux dispositions du Code du Statut Personnel tunisien, notamment :<br/>
  • <strong>Art. 3 CSP</strong> : Conditions de validité du mariage.<br/>
  • <strong>Art. 12 CSP</strong> : La dot (Mahr).<br/>
  • <strong>Art. 32 CSP</strong> : Nécessité de deux témoins.<br/>
  Tout litige sera soumis au Tribunal de Première Instance de Tunis.</p>
</div>
</div>

<div>
  <div class="sign-area">
    <div class="sign-box">
      <!-- Republic of Tunisia notary stamp -->
      <div class="notary-stamp-wrapper">
        <div class="notary-stamp">
          <span class="title-ar">الجمهورية التونسية</span>
          <span class="center-icon">⚖️</span>
          <span class="title-fr">RÉP. TUNISIENNE</span>
          <span class="type-stamp">NOTAIRE PUBLIC</span>
        </div>
      </div>
      ${coSignTag}
      <div class="sign-line">L'Officiant / Notaire<br/><small>${company}</small></div>
    </div>
    <div class="sign-box">${husbandSignTag}<div class="sign-line">L'Époux<br/><small>${c.husbandName || ''}</small></div></div>
    <div class="sign-box">${wifeSignTag}<div class="sign-line">L'Épouse<br/><small>${c.wifeName || ''}</small></div></div>
  </div>
  ${stampFr}
</div>
<div class="legal">Document établi conformément au Code du Statut Personnel tunisien — Loi n° 1956-66 et textes modificatifs.</div>
</div>

<!-- PAGE 2 : ARABE -->
<div class="page page-ar">
${logoTag}
<div class="doc-id">DOC-MARIAGE: ${c.id}</div>
<div style="flex:1">
  ${emblemSvg}
<div class="header">
  <h1>الجمهورية التونسية</h1>
  <div class="sub" style="font-size:12pt;font-weight:700;color:#dc2626;font-style:normal;margin-bottom:6px;letter-spacing:0.5px;">عقد زواج رسمي</div>
  <div class="ref">المرجع : ${refId} &nbsp;|&nbsp; المأذون : ${company} &nbsp;|&nbsp; بتاريخ ${dateArStr}</div>
</div>

<div class="section">
  <div class="stitle">الفصل 1 — الزوجان</div>
  <div class="row" style="flex-direction:row-reverse">
    <div class="col" style="background:#eff6ff;padding:8px;border-radius:6px;">
      <div class="field" style="font-weight:700;color:#1d4ed8;margin-bottom:4px;text-align:right;">♂ الزوج</div>
      <div class="field">الاسم : <span>${c.husbandName || '-'}</span></div>
      <div class="field">رقم الهوية : <span>${c.husbandCin || '-'}</span></div>
      <div class="field">تاريخ الولادة : <span>${c.husbandDob || '-'}</span></div>
    </div>
    <div class="col" style="background:#fdf2f8;padding:8px;border-radius:6px;">
      <div class="field" style="font-weight:700;color:#be185d;margin-bottom:4px;text-align:right;">♀ الزوجة</div>
      <div class="field">الاسم : <span>${c.wifeName || '-'}</span></div>
      <div class="field">رقم الهوية : <span>${c.wifeCin || '-'}</span></div>
      <div class="field">تاريخ الولادة : <span>${c.wifeDob || '-'}</span></div>
    </div>
  </div>
</div>

<div class="section">
  <div class="stitle">الفصل 2 — الشهود (الفصل 32 م.أ.ش)</div>
  <table class="fin" style="direction:rtl"><tr><th>الشاهد</th><th>الاسم الكامل</th><th>رقم الهوية</th></tr>
  <tr><td>الشاهد الأول</td><td>${witness1Ar}</td><td>${c.witness1Cin || '-'}</td></tr>
  <tr><td>الشاهد الثاني</td><td>${witness2Ar}</td><td>${c.witness2Cin || '-'}</td></tr>
  </table>
</div>

<div class="section">
  <div class="stitle">الفصل 3 — الصداق (الفصل 12 م.أ.ش)</div>
  <table class="fin" style="direction:rtl"><tr><th>البيان</th><th>المبلغ</th></tr>
  <tr><td>الصداق (مهر الزواج المتفق عليه)</td><td><strong>${dowry}</strong></td></tr>
  </table>
  <p class="clause" style="margin-top:6px;text-align:right;">الصداق حقٌّ خالص للزوجة وفق الفصل 12 من مجلة الأحوال الشخصية التونسية.</p>
</div>

<div class="section">
  <div class="stitle">الفصل 4 — النظام المالي للزوجين</div>
  <p class="clause" style="text-align:right;">اختار الزوجان نظام : <strong>${regimeAr}</strong>.<br/>
  ${regime.includes('Communauté') ? 'يخضع هذا النظام لأحكام القانون عدد 98-91 المؤرخ في 9 نوفمبر 1998 المتعلق بنظام الاشتراك في الأملاك المشتركة بين الزوجين.' : 'يحتفظ كل زوج بإدارة أمواله الشخصية والتمتع بها والتصرف فيها بحرية.'}</p>
</div>

<div class="section">
  <div class="stitle">الفصل 5 — الأحكام القانونية</div>
  <p class="clause" style="text-align:right;">حُرِّرت هذه الوثيقة وفق أحكام مجلة الأحوال الشخصية التونسية، ولا سيما :<br/>
  • <strong>الفصل 3 م.أ.ش</strong> : شروط صحة الزواج.<br/>
  • <strong>الفصل 12 م.أ.ش</strong> : الصداق.<br/>
  • <strong>الفصل 32 م.أ.ش</strong> : اشتراط شاهدين.<br/>
  يُحال كل نزاع إلى المحكمة الابتدائية المختصة بتونس.</p>
</div>
</div>

<div>
  <div class="sign-area" style="flex-direction:row-reverse">
    <div class="sign-box">
      <!-- Republic of Tunisia notary stamp (Arabic page) -->
      <div class="notary-stamp-wrapper" style="transform: translateX(-50%) rotate(5deg);">
        <div class="notary-stamp">
          <span class="title-ar">الجمهورية التونسية</span>
          <span class="center-icon">⚖️</span>
          <span class="title-fr">RÉP. TUNISIENNE</span>
          <span class="type-stamp">مأذون عمومي</span>
        </div>
      </div>
      ${coSignTag}
      <div class="sign-line">المأذون / الكاتب<br/><small>${company}</small></div>
    </div>
    <div class="sign-box">${husbandSignTag}<div class="sign-line">الزوج<br/><small>${c.husbandName || ''}</small></div></div>
    <div class="sign-box">${wifeSignTag}<div class="sign-line">الزوجة<br/><small>${c.wifeName || ''}</small></div></div>
  </div>
  ${stampAr}
</div>
<div class="legal">وثيقة محررة وفق أحكام مجلة الأحوال الشخصية التونسية — القانون عدد 1956-66 وما طرأ عليه من تعديلات.</div>
</div>

</body></html>`;

    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'] });
    try {
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'load', timeout: 30000 });
        const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true, margin: { top: 0, right: 0, bottom: 0, left: 0 } });
        return pdfBuffer;
    } finally {
        await browser.close();
    }
}

module.exports = { generateMarriagePdf };
