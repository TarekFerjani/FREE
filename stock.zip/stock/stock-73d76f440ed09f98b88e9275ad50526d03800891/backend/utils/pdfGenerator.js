const puppeteer = require('puppeteer');
const QRCode = require('qrcode');

/**
 * Generates the exact same bilingual contract PDF as ContractsPage.tsx
 * Uses the verbatim HTML template from the frontend, with QR code generated server-side.
 */
async function generateContractPdf(contract, clientSignature) {
    const c = contract;
    const currency     = c.currencySymbol  || 'DT';
    const company      = c.companyName     || 'Frigo Inc.';
    const address      = c.companyAddress  || '';
    const phone        = c.companyPhone    || '';
    const fiscal       = c.fiscalId        || '';
    const clientName   = [c.prenom || c.clientPrenom, c.nom || c.clientNom].filter(Boolean).join(' ');
    const cin          = c.cin || c.clientCin || '-';
    const dateStr      = new Date(c.date).toLocaleDateString('fr-TN');
    const dateArStr    = new Date(c.date).toLocaleDateString('ar-TN');
    const refId        = c.id.substring(0, 8).toUpperCase();
    const isSigned     = !!clientSignature;
    const signedAt     = new Date();
    const signedAtStr  = signedAt.toLocaleString('fr-TN');
    const signedAtArStr = signedAt.toLocaleString('ar-TN');
    const typeAr = c.type === 'Location' ? 'إيجار' : 'إعارة صناديق';
    let periodeAr = c.periode || '';
    if (periodeAr.startsWith('Du ') && periodeAr.includes(' au ')) {
        periodeAr = periodeAr.replace('Du ', 'من ').replace(' au ', ' إلى ');
    }

    const verifyUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/sign/${c.id}`;

    // Generate QR code server-side to avoid external API dependency
    const qrDataUrl = await QRCode.toDataURL(verifyUrl, { width: 80, margin: 1, errorCorrectionLevel: 'M' });

    const companyLogoTag   = c.companyLogo      ? `<img src="${c.companyLogo}" class="watermark" />`                                              : '';
    const companySignTag   = c.companySignature  ? `<img src="${c.companySignature}" style="max-height:50px;"/>`                                   : '<div style="height:50px;"></div>';
    const clientSignTag    = isSigned            ? `<img src="${clientSignature}" style="max-height:50px;"/>`                                       : '<div style="height:50px;"></div>';

    const timestampFr = isSigned ? `
    <div class="timestamp" style="display:flex; align-items:center; gap:15px;">
      <img src="${qrDataUrl}" style="width:70px;height:70px;" />
      <div>
        ✅ <strong>Signature électronique validée</strong><br/>
        Horodatage : ${signedAtStr}<br/>
        Signataire : ${clientName} (CIN: ${cin})<br/>
        Référence : ${refId}
      </div>
    </div>` : `
    <div class="timestamp" style="display:flex; align-items:center; gap:15px;">
      <img src="${qrDataUrl}" style="width:70px;height:70px;" />
      <div>
        ⏳ <strong>En attente de signature électronique</strong><br/>
        Scannez ce QR Code avec votre mobile pour valider la signature.<br/>
        Le Locataire : ${clientName} (CIN: ${cin})
      </div>
    </div>`;

    const timestampAr = isSigned ? `
    <div class="timestamp" style="display:flex; align-items:center; justify-content:flex-end; gap:15px; text-align:right; flex-direction:row-reverse;">
      <img src="${qrDataUrl}" style="width:70px;height:70px;" />
      <div>
        ✅ <strong>توقيع إلكتروني معتمد</strong><br/>
        التاريخ والساعة : ${signedAtArStr}<br/>
        الموقّع : ${clientName} (هوية: ${cin})<br/>
        المرجع : ${refId}
      </div>
    </div>` : `
    <div class="timestamp" style="display:flex; align-items:center; justify-content:flex-end; gap:15px; text-align:right; flex-direction:row-reverse;">
      <img src="${qrDataUrl}" style="width:70px;height:70px;" />
      <div>
        ⏳ <strong>في انتظار التوقيع الإلكتروني</strong><br/>
        امسح هذا الرمز بواسطة هاتفك الجوال لإتمام التوقيع.<br/>
        المستأجر : ${clientName} (هوية: ${cin})
      </div>
    </div>`;

    // ─── EXACT HTML FROM ContractsPage.tsx ───────────────────────────────────
    const html = `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"/>
<title>Contrat ${refId}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Source+Sans+3:wght@400;600;700&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Source Sans 3',serif; color:#111; }
  .page { position:relative; width:210mm; height:297mm; padding:15mm 20mm; page-break-after:always; display:flex; flex-direction:column; overflow:hidden; }
  .doc-id { position:absolute; left:6mm; bottom:50%; transform:rotate(-90deg); transform-origin:left bottom; font-family:monospace; font-size:7pt; color:#a0aec0; letter-spacing:1px; white-space:nowrap; }
  .header { color:#1a4fa0; text-align:center; border-bottom:1px solid #e2e8f0; padding-bottom:8px; margin-bottom:12px; }
  .header h1 { font-size:16pt; letter-spacing:1px; margin-bottom:4px; text-transform:uppercase; font-weight:700; }
  .header .ref { font-size:8.5pt; color:#64748b; }
  .section { margin-bottom:10px; }
  .section-title { font-size:9.5pt; font-weight:700; color:#1a4fa0; text-transform:uppercase; letter-spacing:.5px; margin-bottom:6px; }
  .row { display:flex; gap:10px; }
  .col { flex:1; }
  .field { margin-bottom:3px; font-size:9pt; }
  .field span { font-weight:700; color:#111; font-size:9.5pt; }
  .clause { font-size:9pt; line-height:1.4; margin-bottom:4px; }
  .clause strong { font-weight:700; }
  .sign-area { display:flex; justify-content:space-between; margin-top:30px; }
  .sign-box { text-align:center; width:40%; }
  .sign-line { border-top:1px solid #333; margin-top:40px; padding-top:4px; font-size:9pt; }
  .badges { display:flex; gap:8px; margin-bottom:18px; }
  .badge { padding:4px 12px; border-radius:20px; font-size:9pt; font-weight:600; }
  .badge-blue { background:#dbeafe; color:#1e40af; }
  .badge-green { background:#dcfce7; color:#166534; }
  .badge-orange { background:#fff7ed; color:#9a3412; }
  .timestamp { margin-top:8px; padding:8px 12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:4px; font-size:8.5pt; color:#475569; }
  .timestamp strong { color:#1e293b; }
  .legal-margin { position:absolute; right:6mm; top:50%; transform:rotate(-90deg); transform-origin:right top; font-size:7pt; color:#94a3b8; white-space:nowrap; }
  table.fin { width:100%; border-collapse:collapse; font-size:10pt; }
  table.fin td, table.fin th { border:1px solid #ccc; padding:6px 10px; }
  table.fin th { background:#f0f4ff; font-weight:700; }
  .watermark { position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); max-width:70%; max-height:70%; opacity:0.06; pointer-events:none; z-index:0; filter:grayscale(30%); }
  .page-ar { font-family:'Amiri',serif; direction:rtl; }
  .page-ar .section-title { text-align:right; }
  .page-ar .clause { text-align:right; }
  .page-ar .field { text-align:right; }
  @media print {
    @page { margin: 0; size: A4; }
    body { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
    .page { page-break-after:always; }
  }
</style>
</head>
<body>

<!-- ============ PAGE 1 : FRANÇAIS ============ -->
<div class="page">
  ${companyLogoTag}
  <div class="doc-id">DOC SIGN ID: ${c.id}</div>
  <div style="flex: 1;">
    <div class="header">
      <h1>CONTRAT DE ${c.type.toUpperCase()}</h1>
      <div class="ref">Réf : ${refId} &nbsp;|&nbsp; ${company} &nbsp;|&nbsp; Daté du ${dateStr}</div>
    </div>

  <div class="section">
    <div class="section-title">Les parties contractantes</div>
    <div class="row">
      <div class="col">
        <div class="field">Prestataire (Le Loueur) :</div>
        <div class="field"><span>${company}</span></div>
        <div class="field">Adresse : ${address}</div>
        <div class="field">Tél : ${phone}</div>
        ${fiscal ? `<div class="field">Matricule fiscal : ${fiscal}</div>` : ''}
      </div>
      <div class="col">
        <div class="field">Locataire (Le Client) :</div>
        <div class="field"><span>${clientName}</span></div>
        <div class="field">CIN : ${cin}</div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Art. 1 – Objet du contrat</div>
    <p class="clause">Le présent contrat a pour objet la <strong>${c.type.toLowerCase()}</strong> de <strong>${c.nbCaisse} caisse(s) frigorifique(s)</strong> pour une durée convenue de <strong>${c.periode}</strong>, conformément aux dispositions du Code des Obligations et des Contrats tunisien (COC), notamment les articles 729 et suivants relatifs au louage de choses.</p>
  </div>

  <div class="section">
    <div class="section-title">Art. 2 – Durée</div>
    <p class="clause">Le contrat prend effet à compter de la date de signature et pour une durée de <strong>${c.periode}</strong>. À l'expiration de ce délai, le contrat prend fin de plein droit, sauf accord écrit des deux parties pour son renouvellement.</p>
  </div>

  <div class="section">
    <div class="section-title">Art. 3 – Conditions financières</div>
    <table class="fin">
      <tr><th>Désignation</th><th>Montant</th></tr>
      <tr><td>Caution (garantie remboursable)</td><td><strong>${Math.round(c.caution || 0).toLocaleString('fr-FR')} ${currency}</strong></td></tr>
      <tr><td>Avance sur loyer</td><td><strong>${Math.round(c.avance || 0).toLocaleString('fr-FR')} ${currency}</strong></td></tr>
    </table>
    <p class="clause" style="margin-top:8px;">La caution sera restituée au locataire dans un délai de 15 jours suivant la restitution des caisses en bon état, conformément à l'article 830 du COC.</p>
  </div>

  <div class="section">
    <div class="section-title">Art. 4 – Obligations du locataire</div>
    <p class="clause">Le locataire s'engage à : (1) utiliser les caisses conformément à leur destination, (2) les restituer en bon état à la fin du contrat, (3) signaler immédiatement tout sinistre ou dommage au prestataire. Toute dégradation sera à la charge du locataire (Art. 806 COC).</p>
  </div>

  <div class="section">
    <div class="section-title">Art. 5 – Résiliation</div>
    <p class="clause">En cas de manquement grave de l'une ou l'autre partie, le contrat peut être résilié avec un préavis de 15 jours par lettre recommandée. En cas de résiliation fautive du locataire, la caution reste acquise au prestataire à titre de dommages et intérêts.</p>
  </div>

  <div class="section">
    <div class="section-title">Art. 6 – Loi applicable et juridiction</div>
    <p class="clause">Le présent contrat est soumis au droit tunisien. Tout litige sera soumis à la juridiction compétente du Tribunal de Première Instance de Tunis, sauf accord amiable préalable des parties.</p>
  </div>

  </div> <!-- End content wrapper -->

  <div>
    <div class="sign-area">
      <div class="sign-box">
        ${companySignTag}
        <div class="sign-line">Le Prestataire<br/><small>${company}</small></div>
      </div>
      <div class="sign-box">
        ${clientSignTag}
        <div class="sign-line">Le Locataire<br/><small>${clientName}</small></div>
      </div>
    </div>
    ${timestampFr}
  </div>
  <div class="legal-margin">Document établi conformément au Code des Obligations et des Contrats tunisien (COC) – Loi n° 2017-08 et textes connexes.</div>
</div>

<!-- ============ PAGE 2 : ARABE ============ -->
<div class="page page-ar">
  ${companyLogoTag}
  <div class="doc-id">DOC SIGN ID: ${c.id}</div>
  <div style="flex: 1;">
    <div class="header">
      <h1>عقد ${typeAr}</h1>
      <div class="ref">المرجع : ${refId} &nbsp;|&nbsp; ${company} &nbsp;|&nbsp; بتاريخ ${dateArStr}</div>
    </div>

  <div class="section">
    <div class="section-title">الأطراف المتعاقدة</div>
    <div class="row" style="flex-direction:row-reverse;">
      <div class="col">
        <div class="field">المزوّد (المؤجّر) :</div>
        <div class="field"><span>${company}</span></div>
        <div class="field">العنوان : ${address}</div>
        <div class="field">الهاتف : ${phone}</div>
        ${fiscal ? `<div class="field">المعرّف الجبائي : ${fiscal}</div>` : ''}
      </div>
      <div class="col">
        <div class="field">المستأجر (الحريف) :</div>
        <div class="field"><span>${clientName}</span></div>
        <div class="field">رقم بطاقة الهوية : ${cin}</div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">الفصل 1 – موضوع العقد</div>
    <p class="clause">يتعلق هذا العقد بـ<strong>${typeAr}</strong> لـ<strong>${c.nbCaisse} صندوق (صناديق) تبريد</strong> لمدة <strong>${periodeAr}</strong>، وذلك وفقاً لأحكام مجلة الالتزامات والعقود التونسية (م.إ.ع)، ولا سيما الفصول 729 وما يليها المتعلقة بكراء الأشياء.</p>
  </div>

  <div class="section">
    <div class="section-title">الفصل 2 – المدة</div>
    <p class="clause">يسري العقد من تاريخ التوقيع ولمدة <strong>${periodeAr}</strong>. عند انتهاء هذه المدة، يُعدّ العقد منتهياً بقوة القانون، ما لم يتفق الطرفان كتابةً على تجديده.</p>
  </div>

  <div class="section">
    <div class="section-title">الفصل 3 – الشروط المالية</div>
    <table class="fin" style="direction:rtl;">
      <tr><th>البيان</th><th>المبلغ</th></tr>
      <tr><td>الكفالة (ضمان قابل للاسترداد)</td><td><strong>${Math.round(c.caution || 0).toLocaleString('fr-FR')} ${currency}</strong></td></tr>
      <tr><td>دفعة مسبقة على الكراء</td><td><strong>${Math.round(c.avance || 0).toLocaleString('fr-FR')} ${currency}</strong></td></tr>
    </table>
    <p class="clause" style="margin-top:8px;">تُردّ الكفالة للمستأجر في أجل 15 يوماً من تاريخ إرجاع الصناديق في حالة جيدة، وفق الفصل 830 من م.إ.ع.</p>
  </div>

  <div class="section">
    <div class="section-title">الفصل 4 – التزامات المستأجر</div>
    <p class="clause">يلتزم المستأجر بـ: (1) استعمال الصناديق وفق غرضها المحدد، (2) إرجاعها في حالة جيدة عند انتهاء العقد، (3) الإعلام الفوري للمزوّد عن أي عطب أو تلف. يتحمّل المستأجر كل تلف ناجم عن إهماله (الفصل 806 م.إ.ع).</p>
  </div>

  <div class="section">
    <div class="section-title">الفصل 5 – الفسخ</div>
    <p class="clause">في حالة إخلال أحد الطرفين بالتزاماته، يمكن فسخ العقد بعد إشعار مسبق بـ15 يوماً برسالة مضمونة الوصول. في حال كان الفسخ بخطأ المستأجر، تبقى الكفالة من حق المزوّد كتعويض.</p>
  </div>

  <div class="section">
    <div class="section-title">الفصل 6 – القانون المطبق والمحكمة المختصة</div>
    <p class="clause">يخضع هذا العقد للتشريع التونسي. وعند الخلاف، تُحال النزاعات إلى المحكمة الابتدائية المختصة بتونس، ما لم يحصل تسوية ودية بين الطرفين.</p>
  </div>

  </div> <!-- End content wrapper -->

  <div>
    <div class="sign-area" style="flex-direction:row-reverse;">
      <div class="sign-box">
        ${companySignTag}
        <div class="sign-line">المزوّد<br/><small>${company}</small></div>
      </div>
      <div class="sign-box">
        ${clientSignTag}
        <div class="sign-line">المستأجر<br/><small>${clientName}</small></div>
      </div>
    </div>
    ${timestampAr}
  </div>
  <div class="legal-margin">وثيقة محررة وفق أحكام مجلة الالتزامات والعقود التونسية – القانون عدد 2017-08 والنصوص ذات الصلة.</div>
</div>

</body></html>`;

    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    });
    try {
        const page = await browser.newPage();
        // Wait for fonts and images (data URIs) to load
        await page.setContent(html, { waitUntil: 'load', timeout: 30000 });
        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: { top: 0, right: 0, bottom: 0, left: 0 }
        });
        return pdfBuffer;
    } finally {
        await browser.close();
    }
}

module.exports = { generateContractPdf };
