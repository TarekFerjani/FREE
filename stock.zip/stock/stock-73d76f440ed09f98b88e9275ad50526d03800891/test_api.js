const http = require('http');

const data = JSON.stringify({
  clientId: 'admin-uuid-placeholder',
  type: 'Location',
  nbCaisse: 1,
  caution: 10,
  avance: 0,
  periode: '1 mois'
});

const req = http.request(
  'http://localhost:5000/api/contracts',
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  },
  (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => console.log('Response:', res.statusCode, body));
  }
);

req.on('error', (e) => console.error('Error:', e.message));
req.write(data);
req.end();
