# Guide de Déploiement : VPS avec Docker et GitHub Actions

Ce document explique étape par étape comment déployer ce projet (Frontend Vite/React + Backend) sur un Serveur Privé Virtuel (VPS) en utilisant Docker, Docker Compose, et comment automatiser ce processus via GitHub Actions (CI/CD).

## 1. Prérequis

- **Un VPS** (Ubuntu 20.04/22.04 recommandé) avec un accès SSH.
- **Un compte GitHub** avec le code source de ce projet poussé sur un dépôt (repository).
- **Un nom de domaine** (optionnel mais recommandé pour le SSL/HTTPS).

---

## 2. Configuration Initiale du VPS

Connectez-vous à votre VPS via SSH :
```bash
ssh root@IP_DE_VOTRE_VPS
```

### 2.1 Mettre à jour le système et installer dépendances
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install curl git ufw -y
```

### 2.2 Installer Docker et Docker Compose
```bash
# Installer Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Installer Docker Compose
sudo apt-get install docker-compose-plugin -y

# Vérifier l'installation
docker --version
docker compose version
```

### 2.3 Sécuriser avec le Firewall (UFW)
```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

---

## 3. Fichiers Docker Requis

Dans votre projet, vous aurez besoin de configurer vos conteneurs Docker. Créez un fichier `docker-compose.yml` à la racine de votre projet :

### `docker-compose.yml` (Exemple à la racine)
```yaml
version: '3.8'

services:
  frontend:
    build: 
      context: .
      dockerfile: Dockerfile
    ports:
      - "80:80"
    restart: always

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "5000:5000" # Ajustez le port de votre API
    env_file:
      - ./backend/.env
    restart: always
```
*(Assurez-vous que les Dockerfiles du frontend et du backend sont correctement configurés. S'ils n'existent pas ou sont incomplets, nous les créerons).*

---

## 4. Automatisation CI/CD avec GitHub Actions

Nous allons créer un workflow pour que chaque `push` sur la branche `main` déploie automatiquement la nouvelle version sur le VPS.

### 4.1 Préparer les Secrets dans GitHub
Allez sur votre dépôt GitHub : `Settings > Secrets and variables > Actions > New repository secret`.

Ajoutez les secrets suivants :
- `VPS_HOST` : L'adresse IP de votre VPS.
- `VPS_USERNAME` : Le nom d'utilisateur (ex: `root` ou `ubuntu`).
- `VPS_SSH_KEY` : Votre clé privée SSH (celle qui vous permet de vous connecter au VPS sans mot de passe).

#### Générer une clé SSH pour GitHub Actions (si vous n'en avez pas) :
Sur votre machine locale (ou depuis le VPS) :
```bash
ssh-keygen -t rsa -b 4096 -C "github-actions"
# Autoriser la clé publique sur le VPS :
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
```
Copiez ensuite le contenu de la clé **privée** (`cat ~/.ssh/id_rsa`) dans le secret `VPS_SSH_KEY` de GitHub.

### 4.2 Créer le fichier Workflow GitHub Actions
Dans votre projet local, créez ce fichier `.github/workflows/deploy.yml` :

```yaml
name: Déploiement CI/CD Docker sur VPS

on:
  push:
    branches:
      - main # Déclencher au push sur la branche main

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout du code
        uses: actions/checkout@v3

      - name: Déploiement via SSH sur le VPS
        uses: appleboy/ssh-action@v1.0.0
        with:
          host: ${{ secrets.VPS_HOST }}
          username: ${{ secrets.VPS_USERNAME }}
          key: ${{ secrets.VPS_SSH_KEY }}
          script: |
            # Vérifier si le répertoire du projet existe, sinon le cloner
            if [ ! -d "/opt/projet" ]; then
              cd /opt
              git clone https://github.com/VOTRE_NOM_UTILISATEUR/VOTRE_DEPOT.git projet
            fi
            
            # Se déplacer dans le projet
            cd /opt/projet
            
            # Récupérer la dernière version du code
            git pull origin main
            
            # Reconstruire et relancer les conteneurs Docker en arrière-plan
            docker compose down
            docker compose up -d --build
            
            # Nettoyer les anciennes images inutilisées (optionnel)
            docker image prune -f
```
*Remplacez l'URL `VOTRE_NOM_UTILISATEUR/VOTRE_DEPOT.git` par le lien réel de votre dépôt.*

---

## 5. Lancer le Déploiement

1. Sur votre terminal local, ajoutez les fichiers, commitez et pushez :
   ```bash
   git add .
   git commit -m "Configuration Docker et automatisation CI/CD"
   git push origin main
   ```
2. Allez sur l'onglet **Actions** de votre dépôt GitHub. Vous verrez le script s'exécuter.
3. Une fois terminé avec succès (✅), allez sur l'IP de votre VPS dans votre navigateur : `http://IP_DE_VOTRE_VPS`. Votre projet sera en ligne !

## 6. Étapes Suivantes (Recommandé)
- Configurer un nom de domaine avec **Nginx Proxy Manager** ou **Traefik** pour générer automatiquement le HTTPS (certificat SSL Let's Encrypt).
- Extraire les données sensibles (`.env.local`) de GitHub et les paramétrer directement sur le VPS ou via les secrets GitHub.
